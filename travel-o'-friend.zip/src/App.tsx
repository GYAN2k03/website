import React, { useState, useMemo } from 'react';
import {
  Heart,
  Sparkles,
  Search,
  Compass,
  SlidersHorizontal,
  RotateCcw,
  Layers,
  MapPin,
  Globe,
  Utensils,
  TrainFront,
  Building2,
  Camera,
  Car,
  Coffee,
  Ticket,
  Luggage,
  PhoneCall,
  Mail,
  Send,
  MessageCircle,
  CheckCircle2
} from 'lucide-react';

import { PACKAGES_DATA, TourPackage } from './data/packages';
import { STORIES_DATA } from './data/stories';
import { BrandLogo } from './components/BrandLogo';
import { StoryViewerModal } from './components/StoryViewerModal';
import { ItineraryModal } from './components/ItineraryModal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { HorizonSplitSlider } from './components/HorizonSplitSlider';
import { BudgetEstimator } from './components/BudgetEstimator';
import { RouteVisualizer } from './components/RouteVisualizer';

export default function App() {
  // Navigation & Filtering State
  const [masterRegion, setMasterRegion] = useState<'all' | 'domestic' | 'international'>('all');
  const [domesticCategory, setDomesticCategory] = useState<string>('all');
  const [internationalCategory, setInternationalCategory] = useState<string>('all');
  const [searchKeyword, setSearchKeyword] = useState<string>('');
  const [maxBudget, setMaxBudget] = useState<number>(70000);

  // Modals & Drawers State
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);
  const [activeItineraryPackage, setActiveItineraryPackage] = useState<TourPackage | null>(null);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [savedPackageIds, setSavedPackageIds] = useState<string[]>(['kashmir', 'vietnam']);

  // Callback Form State
  const [cbName, setCbName] = useState('');
  const [cbPhone, setCbPhone] = useState('');
  const [cbPackage, setCbPackage] = useState('Darjeeling (5D/4N) — Offer ₹4,999/-');
  const [cbTravelers, setCbTravelers] = useState('');
  const [cbNotes, setCbNotes] = useState('');

  // Wishlist Handling
  const toggleSavePackage = (id: string) => {
    setSavedPackageIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const savedPackages = useMemo(() => {
    return PACKAGES_DATA.filter(pkg => savedPackageIds.includes(pkg.id));
  }, [savedPackageIds]);

  // Filtering Logic
  const filteredDomesticPackages = useMemo(() => {
    return PACKAGES_DATA.filter(pkg => {
      if (pkg.part !== 'domestic') return false;
      const matchCat = domesticCategory === 'all' || pkg.category === domesticCategory;
      const query = searchKeyword.toLowerCase().trim();
      const matchKw =
        !query ||
        pkg.title.toLowerCase().includes(query) ||
        pkg.bengaliName.toLowerCase().includes(query) ||
        pkg.overview.toLowerCase().includes(query);
      const matchPrice = pkg.price <= maxBudget;
      return matchCat && matchKw && matchPrice;
    });
  }, [domesticCategory, searchKeyword, maxBudget]);

  const filteredInternationalPackages = useMemo(() => {
    return PACKAGES_DATA.filter(pkg => {
      if (pkg.part !== 'international') return false;
      const matchCat = internationalCategory === 'all' || pkg.category === internationalCategory;
      const query = searchKeyword.toLowerCase().trim();
      const matchKw =
        !query ||
        pkg.title.toLowerCase().includes(query) ||
        pkg.bengaliName.toLowerCase().includes(query) ||
        pkg.overview.toLowerCase().includes(query);
      const matchPrice = pkg.price <= maxBudget;
      return matchCat && matchKw && matchPrice;
    });
  }, [internationalCategory, searchKeyword, maxBudget]);

  // WhatsApp Dispatch Helper
  const openWhatsApp = (message: string) => {
    const url = `https://wa.me/918017559717?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleBookPackage = (pkg: TourPackage) => {
    const bonusLine =
      pkg.part === 'international'
        ? '• Inclusions: 3★ Hotel + Daily Breakfast + Sightseeing & Transfers\n'
        : '• Special Offer: Includes Daily 3 Meals + Sleeper Train + 3★ Hotel + Sightseeing & Transfers\n';
    openWhatsApp(
      `Hello Travel O' Friend! I want to book / enquire about this Tour Package:\n` +
        `• Package: ${pkg.title}\n` +
        `• Duration: ${pkg.duration}${pkg.tierOptions ? ` (${pkg.tierOptions})` : ''}\n` +
        `• Special Offer Rate: ₹${pkg.price.toLocaleString('en-IN')}/- Per Person\n` +
        bonusLine +
        `• Office: B-1/222, Kalyani, Nadia, West Bengal\n` +
        `Please share upcoming departure dates and booking confirmation details!`
    );
  };

  const handleCallbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cbName.trim() || !cbPhone.trim()) return;
    openWhatsApp(
      `Hello Travel O' Friend! Please arrange a quick callback & PDF quote:\n` +
        `• Name: ${cbName.trim()}\n` +
        `• Phone/WhatsApp: ${cbPhone.trim()}\n` +
        `• Selected Tour: ${cbPackage}\n` +
        `• Travelers & Month: ${cbTravelers.trim() || 'Flexible'}\n` +
        `• Notes: ${cbNotes.trim() || 'None'}`
    );
  };

  const handleSendWishlist = () => {
    if (savedPackages.length === 0) return;
    const lines = savedPackages
      .map(p => `• ${p.title} (${p.duration} - ₹${p.price.toLocaleString('en-IN')}/-)`)
      .join('\n');
    openWhatsApp(
      `Hello Travel O' Friend! Here is my shortlisted tour package list:\n${lines}\nPlease share batch dates and booking details.`
    );
  };

  const resetFilters = () => {
    setSearchKeyword('');
    setMaxBudget(70000);
    setMasterRegion('all');
    setDomesticCategory('all');
    setInternationalCategory('all');
  };

  return (
    <div className="min-h-screen relative selection:bg-purple-600 selection:text-white">
      {/* Liquid Drop Ambient Mesh Orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="orb-float-1 absolute -top-28 -left-24 w-[46rem] h-[46rem] bg-gradient-to-br from-purple-200/80 via-purple-100/50 to-cyan-100/55 blur-[95px]" />
        <div className="orb-float-2 absolute top-[16%] -right-28 w-[44rem] h-[44rem] bg-gradient-to-tr from-sky-200/75 via-cyan-100/55 to-indigo-100/60 blur-[95px]" />
        <div className="orb-float-3 absolute bottom-[6%] left-[16%] w-[48rem] h-[48rem] bg-gradient-to-r from-cyan-100/70 via-purple-100/60 to-sky-100/65 blur-[105px]" />
      </div>

      {/* 1. FLOATING NAVIGATION BAR */}
      <header className="sticky top-4 z-40 px-4 sm:px-6 max-w-7xl mx-auto">
        <nav className="cos-glass-strong rounded-full px-3 sm:px-5 py-2.5 flex items-center justify-between shadow-lg">
          {/* Brand Logo & Name */}
          <a href="#" className="flex items-center gap-3 group" aria-label="Travel O' Friend Home">
            <BrandLogo size="md" className="group-hover:scale-105 transition-transform" />
            <div>
              <span className="font-display font-bold text-lg sm:text-xl tracking-tight text-slate-900 block leading-none">
                Travel <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-purple-600 to-orange-500">O' Friend</span>
              </span>
            </div>
          </a>

          {/* Center Glass Navigation Links */}
          <div className="hidden xl:flex items-center gap-1 bg-purple-100/40 p-1.5 rounded-full border border-white/80">
            <a
              href="#domestic-tours"
              onClick={() => setMasterRegion('all')}
              className="px-4 py-2 rounded-full text-xs font-bold text-slate-900 hover:bg-white hover:shadow-sm transition-all"
            >
              Domestic
            </a>
            <a
              href="#international-tours"
              onClick={() => setMasterRegion('all')}
              className="px-4 py-2 rounded-full text-xs font-bold text-slate-900 hover:bg-white hover:shadow-sm transition-all"
            >
              International
            </a>
            <a
              href="#gallery-section"
              className="px-4 py-2 rounded-full text-xs font-bold text-slate-900 hover:bg-white hover:shadow-sm transition-all"
            >
              Gallery
            </a>
            <a
              href="#route-map"
              className="px-4 py-2 rounded-full text-xs font-bold text-slate-900 hover:bg-white hover:shadow-sm transition-all"
            >
              Route Map
            </a>
            <a
              href="#budget-simulator"
              className="px-4 py-2 rounded-full text-xs font-bold text-slate-900 hover:bg-white hover:shadow-sm transition-all"
            >
              Estimator
            </a>
            <a
              href="#about-services"
              className="px-4 py-2 rounded-full text-xs font-bold text-slate-900 hover:bg-white hover:shadow-sm transition-all"
            >
              About
            </a>
            <a
              href="#reviews-contact"
              className="px-4 py-2 rounded-full text-xs font-bold text-slate-900 hover:bg-white hover:shadow-sm transition-all"
            >
              Reviews
            </a>
          </div>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setIsWishlistOpen(true)}
              className="relative w-11 h-11 rounded-full bg-white/90 hover:bg-white border border-white shadow-sm flex items-center justify-center text-slate-900 hover:scale-105 transition-all"
              aria-label="Open Saved Shortlist"
            >
              <Heart className="w-5 h-5 text-purple-600" />
              {savedPackageIds.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-r from-purple-600 to-cyan-500 text-white text-[10px] font-bold flex items-center justify-center shadow">
                  {savedPackageIds.length}
                </span>
              )}
            </button>

            <a
              href="#reviews-contact"
              className="cos-gradient-btn px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Plan My Trip</span>
            </a>
          </div>
        </nav>
      </header>



      {/* 2. STUNNING TRAVEL HERO SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-14">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Bengali Tagline & Headings */}
          <div className="lg:col-span-7 space-y-5 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full cos-glass text-xs font-extrabold text-purple-700 uppercase tracking-widest border border-white">
              <span className="w-2 h-2 rounded-full bg-purple-600 animate-ping" />
              <span>Kalyani Headquarters • চলে আসুন আমাদের অফিসে</span>
            </div>

            <div>
              <p className="text-xl sm:text-2xl font-bold text-orange-600 mb-2 font-display">
                স্বপ্ন নয়, এবার সত্যি করুন ঘুরে দেখার ইচ্ছেগুলো!
              </p>
              <h1 className="font-display font-bold text-3xl sm:text-5xl lg:text-[3.35rem] leading-[1.08] tracking-tight text-slate-900">
                Not Just a Dream, Now Make Your <br className="hidden sm:inline" />
                <span className="font-serif-italic font-normal text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-blue-600 to-orange-500 text-4xl sm:text-6xl">
                  Travel Wishes Come True!
                </span>
              </h1>
            </div>

            <p className="text-base sm:text-lg text-slate-700 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-semibold">
              <span className="text-purple-600 font-bold">Best Travel, Best Experience – Right Within Your Budget!</span> Explore <strong className="text-slate-900">14 All-Inclusive Domestic Circuits</strong> starting at <strong className="text-rose-600">₹4,999/-</strong> & <strong className="text-slate-900">11 International Escapes</strong> starting at <strong className="text-blue-600">₹26,999/-</strong>.
            </p>

            {/* 5 Translated Flyer Inclusion Pillars Banner */}
            <div className="cos-glass-strong p-4 rounded-3xl border-2 border-white shadow-sm">
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[11px] font-extrabold uppercase tracking-widest text-white bg-gradient-to-r from-orange-500 to-amber-500 px-3 py-0.5 rounded-full">
                  ★ ALL-INCLUSIVE PACKAGE INCLUSIONS (প্যাকেজে থাকছে)
                </span>
                <span className="text-[11px] font-bold text-slate-500 hidden sm:inline">Zero Hidden Costs</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-left">
                <div className="bg-white/90 p-2.5 rounded-xl border border-white flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-orange-500/15 text-orange-600 flex items-center justify-center shrink-0">
                    <Utensils className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-slate-900 block leading-tight">Daily 3 Meals</span>
                    <span className="text-[9px] text-slate-500 block">প্রতিদিন ৩ বেলা খাওয়া</span>
                  </div>
                </div>

                <div className="bg-white/90 p-2.5 rounded-xl border border-white flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/15 text-blue-600 flex items-center justify-center shrink-0">
                    <TrainFront className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-slate-900 block leading-tight">Sleeper Train</span>
                    <span className="text-[9px] text-slate-500 block">ট্রেন টিকিট অন্তর্ভুক্ত</span>
                  </div>
                </div>

                <div className="bg-white/90 p-2.5 rounded-xl border border-white flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-purple-500/15 text-purple-600 flex items-center justify-center shrink-0">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-slate-900 block leading-tight">3-Star Hotels</span>
                    <span className="text-[9px] text-slate-500 block">৩ স্টার হোটেল</span>
                  </div>
                </div>

                <div className="bg-white/90 p-2.5 rounded-xl border border-white flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-600 flex items-center justify-center shrink-0">
                    <Camera className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-slate-900 block leading-tight">All Sightseeing</span>
                    <span className="text-[9px] text-slate-500 block">সমস্ত সাইটসিন</span>
                  </div>
                </div>

                <div className="bg-white/90 p-2.5 rounded-xl border border-white flex items-center gap-2 col-span-2 sm:col-span-1">
                  <div className="w-8 h-8 rounded-lg bg-rose-500/15 text-rose-600 flex items-center justify-center shrink-0">
                    <Car className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-slate-900 block leading-tight">Pickups & Drops</span>
                    <span className="text-[9px] text-slate-500 block">সমস্ত পিক অ্যান্ড ড্রপ</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Immersive Layered Hero Visual Card */}
          <div className="lg:col-span-5">
            <div className="cos-glass-strong p-3.5 rounded-3xl relative group shadow-2xl">
              <div className="relative h-[25rem] sm:h-[28rem] rounded-2xl overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1595815771614-ade9d652a65d?auto=format&fit=crop&w=1200&q=85"
                  alt="Kashmir Dal Lake Shikara & Himalayan Peaks"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/25 to-transparent" />

                {/* Floating Top Pill */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between gap-2">
                  <span className="px-3.5 py-1.5 rounded-full bg-rose-600 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-lg">
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    SPECIAL MEGA OFFER
                  </span>
                  <span className="px-3 py-1.5 rounded-full bg-white/90 backdrop-blur-md text-slate-900 text-xs font-extrabold shadow">
                    Darjeeling @ ₹4,999/-
                  </span>
                </div>

                {/* Bottom Glass Overlay Card */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-2xl bg-white/90 backdrop-blur-xl border border-white flex items-center justify-between gap-3 shadow-lg">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-rose-600 block">
                      Mega Flyer Offer • 10 Days | 9 Nights
                    </span>
                    <h2 className="font-display font-bold text-base sm:text-lg text-slate-900">
                      Magnificent Kashmir (কাশ্মীর)
                    </h2>
                    <p className="text-xs text-slate-500 font-semibold">
                      <span className="line-through text-slate-400 mr-1">₹15,999/-</span> Best Offer Per Person
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const kashmir = PACKAGES_DATA.find(p => p.id === 'kashmir');
                      if (kashmir) handleBookPackage(kashmir);
                    }}
                    className="cos-gradient-btn px-4 py-2.5 rounded-xl text-sm font-extrabold shrink-0"
                  >
                    ₹12,999/-
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Search & Filter Deck */}
        <div className="cos-glass-strong rounded-3xl p-4 sm:p-6 mt-10 shadow-lg border-2 border-white">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
            {/* Keyword Search */}
            <div className="md:col-span-4 flex items-center gap-3 bg-white/80 px-4 py-3 rounded-2xl border border-white">
              <Search className="w-5 h-5 text-purple-600 shrink-0" />
              <div className="w-full">
                <label
                  htmlFor="quickSearchInput"
                  className="block text-[10px] font-bold uppercase tracking-wider text-slate-400"
                >
                  Search Destination (English or বাংলা)
                </label>
                <input
                  id="quickSearchInput"
                  type="text"
                  value={searchKeyword}
                  onChange={e => setSearchKeyword(e.target.value)}
                  placeholder="e.g., Darjeeling, Kashmir, Spiti, Ladakh, Goa, Vietnam..."
                  className="w-full bg-transparent text-sm font-semibold text-slate-900 focus:outline-none placeholder:text-slate-400"
                />
              </div>
            </div>

            {/* Region Switcher */}
            <div className="md:col-span-3 flex items-center gap-3 bg-white/80 px-4 py-3 rounded-2xl border border-white">
              <Compass className="w-5 h-5 text-cyan-600 shrink-0" />
              <div className="w-full">
                <label
                  htmlFor="quickRegionSelect"
                  className="block text-[10px] font-bold uppercase tracking-wider text-slate-400"
                >
                  Tour Division
                </label>
                <select
                  id="quickRegionSelect"
                  value={masterRegion}
                  onChange={e => setMasterRegion(e.target.value as any)}
                  className="w-full bg-transparent text-sm font-bold text-slate-900 focus:outline-none cursor-pointer"
                >
                  <option value="all">All Tours (25 Packages)</option>
                  <option value="domestic">Part 01: Domestic Tours (14)</option>
                  <option value="international">Part 02: International Tours (11)</option>
                </select>
              </div>
            </div>

            {/* Max Budget Slider */}
            <div className="md:col-span-3 bg-white/80 px-4 py-2.5 rounded-2xl border border-white">
              <div className="flex items-center justify-between mb-1">
                <label
                  htmlFor="quickBudgetSlider"
                  className="text-[10px] font-bold uppercase tracking-wider text-slate-400"
                >
                  Max Offer Price / Person
                </label>
                <span className="font-display font-bold text-xs text-purple-600">
                  ₹{maxBudget.toLocaleString('en-IN')}
                </span>
              </div>
              <input
                id="quickBudgetSlider"
                type="range"
                min={4999}
                max={70000}
                step={500}
                value={maxBudget}
                onChange={e => setMaxBudget(Number(e.target.value))}
                className="w-full"
              />
            </div>

            {/* Instant Filter / Reset Button */}
            <div className="md:col-span-2 flex gap-2">
              <a
                href="#catalogue-top"
                className="cos-gradient-btn w-full py-3.5 px-4 rounded-2xl font-display font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>Explore</span>
              </a>
              <button
                type="button"
                onClick={resetFilters}
                className="px-3.5 py-3.5 rounded-2xl bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 text-xs font-bold"
                title="Reset Filters"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. INTERACTIVE 9:16 "TRAVEL STORIES" BAR */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="cos-glass rounded-3xl p-5 sm:p-6 shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-600 animate-ping" />
              <h2 className="font-display font-bold text-lg sm:text-xl text-slate-900">
                Interactive 9:16 Special Offer Stories
              </h2>
            </div>
            <span className="text-xs font-semibold text-slate-500">
              Tap any destination capsule to preview offer prices & vertical reel
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
            {STORIES_DATA.map((story, idx) => (
              <button
                key={story.id}
                type="button"
                onClick={() => setActiveStoryIndex(idx)}
                className="cos-glass p-2.5 rounded-2xl flex items-center gap-3 hover:bg-white transition-all text-left group border border-white"
              >
                <div className="p-0.5 rounded-full bg-gradient-to-tr from-purple-500 via-blue-500 to-cyan-400 shrink-0">
                  <img
                    src={story.img}
                    alt={story.title}
                    className="w-12 h-12 rounded-full object-cover border-2 border-white group-hover:scale-105 transition-transform"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="min-w-0">
                  <span className="font-display font-bold text-xs sm:text-sm text-slate-900 block truncate">
                    {story.title}
                  </span>
                  <span className="text-[11px] font-bold text-purple-600 block truncate">
                    {story.sub}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 4. TWO-PART DESTINATION & TOUR PACKAGES CATALOGUE */}
      <section id="catalogue-top" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Master Switcher Bar */}
        <div className="cos-glass-strong rounded-3xl p-4 sm:p-6 mb-10 flex flex-col lg:flex-row items-center justify-between gap-4 border-2 border-white shadow-md">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 to-cyan-500 text-white flex items-center justify-center shadow-md shrink-0">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-700">
                  Special Best Offer • আজই বুক করুন!
                </span>
                <span className="text-xs font-bold text-slate-500">All 25 Curated Packages</span>
              </div>
              <h2 className="font-display font-bold text-xl sm:text-3xl text-slate-900 mt-0.5">
                Two-Part Tour Catalogue: Domestic & International
              </h2>
            </div>
          </div>

          {/* Master Switcher Tabs */}
          <div className="flex flex-wrap items-center gap-2 bg-purple-100/50 p-1.5 rounded-full border border-white">
            <button
              type="button"
              onClick={() => setMasterRegion('all')}
              className={`px-5 py-2.5 rounded-full text-xs font-extrabold transition-all ${
                masterRegion === 'all'
                  ? 'bg-slate-900 text-white shadow'
                  : 'text-slate-800 hover:bg-white'
              }`}
            >
              All Tours (25)
            </button>
            <button
              type="button"
              onClick={() => setMasterRegion('domestic')}
              className={`px-5 py-2.5 rounded-full text-xs font-extrabold transition-all ${
                masterRegion === 'domestic'
                  ? 'bg-slate-900 text-white shadow'
                  : 'text-slate-800 hover:bg-white'
              }`}
            >
              Part 01: Domestic India (14)
            </button>
            <button
              type="button"
              onClick={() => setMasterRegion('international')}
              className={`px-5 py-2.5 rounded-full text-xs font-extrabold transition-all ${
                masterRegion === 'international'
                  ? 'bg-slate-900 text-white shadow'
                  : 'text-slate-800 hover:bg-white'
              }`}
            >
              Part 02: International (11)
            </button>
          </div>
        </div>

        {/* PART 01: DOMESTIC TOURS (14 PACKAGES) */}
        {(masterRegion === 'all' || masterRegion === 'domestic') && (
          <div id="domestic-tours" className="mb-20 scroll-mt-24">
            <div className="cos-glass-strong rounded-3xl p-6 sm:p-8 mb-8 border-l-8 border-l-purple-600 shadow-md">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-600 text-white text-xs font-bold uppercase tracking-wider">
                      <MapPin className="w-3.5 h-3.5" /> PART 01 • DOMESTIC TOURS (14 PLACES)
                    </span>
                    <span className="px-3 py-1 rounded-full bg-amber-500/15 text-amber-800 text-xs font-extrabold">
                      Includes 3 Meals + Sleeper Train + 3★ Hotel + Sightseeing + Pick & Drop
                    </span>
                  </div>
                  <h3 className="font-display font-bold text-3xl sm:text-4xl text-slate-900">
                    Explore Incredible{' '}
                    <span className="font-serif-italic font-normal text-purple-600">
                      India — Mega Budget Offers
                    </span>
                  </h3>
                  <p className="text-sm text-slate-600 mt-1 font-medium">
                    All 14 promotional destinations translated from our official domestic flyer—book now to lock in these special discounted per-person rates!
                  </p>
                </div>
                <span className="px-4 py-2 rounded-full bg-white text-purple-600 font-display font-bold text-xs shadow-sm border border-slate-100 self-start md:self-auto shrink-0">
                  Showing {filteredDomesticPackages.length} of 14 Domestic Tours
                </span>
              </div>

              {/* Domestic Category Filter Pills */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar mt-6 pt-5 border-t border-white/80">
                <button
                  type="button"
                  onClick={() => setDomesticCategory('all')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    domesticCategory === 'all'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  All 14 Domestic Places
                </button>
                <button
                  type="button"
                  onClick={() => setDomesticCategory('Himalayas')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    domesticCategory === 'Himalayas'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Himalayas & North (6)
                </button>
                <button
                  type="button"
                  onClick={() => setDomesticCategory('Northeast')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    domesticCategory === 'Northeast'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Meghalaya, Kaziranga & Arunachal (3)
                </button>
                <button
                  type="button"
                  onClick={() => setDomesticCategory('Beach')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    domesticCategory === 'Beach'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Goa, Andaman & Vizag (3)
                </button>
                <button
                  type="button"
                  onClick={() => setDomesticCategory('RoyalSouth')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    domesticCategory === 'RoyalSouth'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Kerala & Rajasthan (2)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
              {filteredDomesticPackages.map(pkg => (
                <article
                  key={pkg.id}
                  className="cos-glass rounded-3xl p-3.5 flex flex-col justify-between cos-card shadow-sm"
                >
                  <div>
                    {/* Image Container */}
                    <div className="relative h-56 rounded-2xl overflow-hidden mb-4">
                      <img
                        src={pkg.image}
                        alt={pkg.title}
                        className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

                      {/* Top Badges */}
                      <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
                        <span className="px-3 py-1 rounded-full bg-gradient-to-r from-rose-600 via-orange-500 to-amber-500 text-white text-[10px] font-extrabold uppercase tracking-wider shadow">
                          {pkg.scarcity}
                        </span>
                        <button
                          type="button"
                          onClick={() => toggleSavePackage(pkg.id)}
                          className="w-9 h-9 rounded-full bg-white/90 backdrop-blur flex items-center justify-center shadow hover:scale-110 transition-transform"
                          aria-label="Save to Wishlist"
                        >
                          <Heart
                            className={`w-4 h-4 ${
                              savedPackageIds.includes(pkg.id)
                                ? 'text-rose-500 fill-rose-500'
                                : 'text-slate-500'
                            }`}
                          />
                        </button>
                      </div>

                      {/* Bottom Duration & Extra Note Pill */}
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2 text-white">
                        <span className="px-3 py-1 rounded-xl bg-slate-950/85 backdrop-blur-md text-xs font-extrabold border border-white/20">
                          {pkg.duration}
                        </span>
                        <span className="px-2.5 py-1 rounded-xl bg-white/95 text-slate-900 text-[10px] font-extrabold truncate">
                          {pkg.extraNote}
                        </span>
                      </div>
                    </div>

                    {/* Title, Bengali Subtitle & Highlights */}
                    <div className="px-1.5">
                      <span className="text-[11px] font-bold text-purple-600 block mb-0.5">
                        {pkg.bengaliName}
                      </span>
                      <h4 className="font-display font-bold text-lg sm:text-xl text-slate-900 leading-snug mb-2">
                        {pkg.title}
                      </h4>
                      <p className="text-xs text-slate-600 line-clamp-2 mb-3.5 leading-relaxed">
                        {pkg.overview}
                      </p>
                      <div className="flex flex-wrap gap-1.5 mb-4">
                        {pkg.highlights.map((h, i) => (
                          <span
                            key={i}
                            className="px-2.5 py-1 rounded-lg bg-white/85 border border-white text-[11px] font-semibold text-slate-700"
                          >
                            {h}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Pricing & Actions */}
                  <div className="px-1.5 pt-3.5 border-t border-white flex items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center flex-wrap gap-1">
                        {pkg.oldPrice && (
                          <span className="text-xs font-bold text-rose-500 line-through mr-1.5">
                            ₹{pkg.oldPrice.toLocaleString('en-IN')}/-
                          </span>
                        )}
                        <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded">
                          Best Offer
                        </span>
                      </div>
                      <div className="mt-0.5">
                        <span className="font-display font-extrabold text-xl sm:text-2xl text-slate-900">
                          ₹{pkg.price.toLocaleString('en-IN')}/-
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold uppercase ml-1">
                          Per Person
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setActiveItineraryPackage(pkg)}
                        className="px-3 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-900 border border-slate-200 text-xs font-bold shadow-sm"
                      >
                        Details
                      </button>
                      <button
                        type="button"
                        onClick={() => handleBookPackage(pkg)}
                        className="cos-gradient-btn px-4 py-2.5 rounded-xl text-xs font-bold"
                      >
                        Book
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        )}

        {/* PART 02: INTERNATIONAL TOURS (11 PACKAGES) */}
        {(masterRegion === 'all' || masterRegion === 'international') && (
          <div id="international-tours" className="scroll-mt-24">
            <div className="cos-glass-strong rounded-3xl p-6 sm:p-8 mb-8 border-l-8 border-l-cyan-500 shadow-md">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-600 text-white text-xs font-bold uppercase tracking-wider">
                      <Globe className="w-3.5 h-3.5" /> PART 02 • INTERNATIONAL TOURS (11 PACKAGES)
                    </span>
                    <span className="px-3 py-1 rounded-full bg-cyan-500/15 text-cyan-800 text-xs font-extrabold">
                      3★ Hotels + Daily Breakfast + Transfers + Sightseeing
                    </span>
                  </div>
                  <h3 className="font-display font-bold text-3xl sm:text-4xl text-slate-900">
                    Explore Global Horizons &{' '}
                    <span className="font-serif-italic font-normal text-blue-600">
                      International Escapes
                    </span>
                  </h3>
                  <p className="text-sm text-slate-600 mt-1 font-medium">
                    Curated international group and customized packages with 3-star accommodations, daily breakfast, airport transfers, and guided sightseeing included.
                  </p>
                </div>
                <span className="px-4 py-2 rounded-full bg-white text-cyan-700 font-display font-bold text-xs shadow-sm border border-slate-100 self-start md:self-auto shrink-0">
                  Showing {filteredInternationalPackages.length} of 11 International Tours
                </span>
              </div>

              {/* International Inclusions Banner */}
              <div className="mt-5 p-4 rounded-2xl bg-gradient-to-r from-cyan-50/90 via-white/90 to-purple-50/90 border border-white grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="flex items-center gap-2.5 bg-white p-2.5 rounded-xl border border-slate-100">
                  <Coffee className="w-4 h-4 text-orange-500 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Daily Breakfast</span>
                    <span className="text-[10px] text-slate-500 block">Included Every Morning</span>
                  </div>
                </div>
                <div className="flex items-center gap-2.5 bg-white p-2.5 rounded-xl border border-slate-100">
                  <Building2 className="w-4 h-4 text-purple-600 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">3★ Hotel Stay</span>
                    <span className="text-[10px] text-slate-500 block">Quality Stays</span>
                  </div>
                </div>
                <div className="flex items-center gap-2.5 bg-white p-2.5 rounded-xl border border-slate-100">
                  <Car className="w-4 h-4 text-blue-600 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">All Pickup & Drop</span>
                    <span className="text-[10px] text-slate-500 block">Airport Transfers</span>
                  </div>
                </div>
                <div className="flex items-center gap-2.5 bg-white p-2.5 rounded-xl border border-slate-100">
                  <Ticket className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Sightseeing & Entry</span>
                    <span className="text-[10px] text-slate-500 block">All Entry Fees Included</span>
                  </div>
                </div>
              </div>

              {/* International Category Filter Pills */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar mt-5 pt-4 border-t border-white/80">
                <button
                  type="button"
                  onClick={() => setInternationalCategory('all')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    internationalCategory === 'all'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  All International (11)
                </button>
                <button
                  type="button"
                  onClick={() => setInternationalCategory('Thailand')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    internationalCategory === 'Thailand'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Bangkok, Pattaya, Phuket & Krabi (3)
                </button>
                <button
                  type="button"
                  onClick={() => setInternationalCategory('Malaysia')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    internationalCategory === 'Malaysia'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Kuala Lumpur & Langkawi (2)
                </button>
                <button
                  type="button"
                  onClick={() => setInternationalCategory('Vietnam')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    internationalCategory === 'Vietnam'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Vietnam & Phu Quoc (2)
                </button>
                <button
                  type="button"
                  onClick={() => setInternationalCategory('SingaporeBali')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    internationalCategory === 'SingaporeBali'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Bali & Singapore (2)
                </button>
                <button
                  type="button"
                  onClick={() => setInternationalCategory('DubaiSrilanka')}
                  className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                    internationalCategory === 'DubaiSrilanka'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-white/80 text-slate-800 hover:bg-white'
                  }`}
                >
                  Dubai, Abu Dhabi & Sri Lanka (2)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
              {filteredInternationalPackages.map(pkg => (
                <article
                  key={pkg.id}
                  className="cos-glass rounded-3xl p-3.5 flex flex-col justify-between cos-card shadow-sm"
                >
                  <div>
                    {/* Image Container */}
                    <div className="relative h-56 rounded-2xl overflow-hidden mb-4">
                      <img
                        src={pkg.image}
                        alt={pkg.title}
                        className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

                      {/* Top Badges */}
                      <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
                        <span className="px-3 py-1 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 text-white text-[10px] font-extrabold uppercase tracking-wider shadow">
                          {pkg.scarcity}
                        </span>
                        <button
                          type="button"
                          onClick={() => toggleSavePackage(pkg.id)}
                          className="w-9 h-9 rounded-full bg-white/90 backdrop-blur flex items-center justify-center shadow hover:scale-110 transition-transform"
                          aria-label="Save to Wishlist"
                        >
                          <Heart
                            className={`w-4 h-4 ${
                              savedPackageIds.includes(pkg.id)
                                ? 'text-rose-500 fill-rose-500'
                                : 'text-slate-500'
                            }`}
                          />
                        </button>
                      </div>

                      {/* Bottom Duration & Extra Note Pill */}
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2 text-white">
                        <span className="px-3 py-1 rounded-xl bg-slate-950/85 backdrop-blur-md text-xs font-extrabold border border-white/20">
                          {pkg.duration}
                        </span>
                        <span className="px-2.5 py-1 rounded-xl bg-white/95 text-slate-900 text-[10px] font-extrabold truncate">
                          {pkg.extraNote}
                        </span>
                      </div>
                    </div>

                    {/* Title, Bengali Subtitle & Highlights */}
                    <div className="px-1.5">
                      <span className="text-[11px] font-bold text-purple-600 block mb-0.5">
                        {pkg.bengaliName}
                      </span>
                      <h4 className="font-display font-bold text-lg sm:text-xl text-slate-900 leading-snug mb-2">
                        {pkg.title}
                      </h4>
                      <p className="text-xs text-slate-600 line-clamp-2 mb-3.5 leading-relaxed">
                        {pkg.overview}
                      </p>
                      <div className="flex flex-wrap gap-1.5 mb-4">
                        {pkg.highlights.map((h, i) => (
                          <span
                            key={i}
                            className="px-2.5 py-1 rounded-lg bg-white/85 border border-white text-[11px] font-semibold text-slate-700"
                          >
                            {h}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Pricing & Actions */}
                  <div className="px-1.5 pt-3.5 border-t border-white flex items-center justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-cyan-800 bg-cyan-100 px-1.5 py-0.5 rounded">
                        {pkg.tierOptions ? pkg.tierOptions : 'Special Rate'}
                      </span>
                      <div className="mt-0.5">
                        <span className="font-display font-extrabold text-xl sm:text-2xl text-slate-900">
                          ₹{pkg.price.toLocaleString('en-IN')}/-
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold uppercase ml-1">
                          Per Person
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setActiveItineraryPackage(pkg)}
                        className="px-3 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-900 border border-slate-200 text-xs font-bold shadow-sm"
                      >
                        Details
                      </button>
                      <button
                        type="button"
                        onClick={() => handleBookPackage(pkg)}
                        className="cos-gradient-btn px-4 py-2.5 rounded-xl text-xs font-bold"
                      >
                        Book
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* 5. ANIMATED DESTINATION GALLERY & DAY/NIGHT SPLIT SLIDER */}
      <section id="gallery-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 scroll-mt-20">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="px-3.5 py-1.5 rounded-full cos-glass text-xs font-bold uppercase tracking-widest text-purple-600">
            Aquamorphic Visuals
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-5xl text-slate-900 mt-3">
            Day-to-Night{' '}
            <span className="font-serif-italic font-normal text-blue-600">Atmosphere & Gallery</span>
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Drag the interactive split slider to compare Dal Lake at Golden Sunrise vs. Starlit Houseboat Night, or explore our curated destination frames.
          </p>
        </div>

        {/* Interactive Horizon Split Slider */}
        <HorizonSplitSlider />

        {/* Bento Gallery Cards */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          <div className="md:col-span-5 cos-glass p-3 rounded-3xl cos-card group shadow-sm">
            <div className="relative h-64 rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=900&q=80"
                alt="Ba Na Hills Golden Bridge Vietnam"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-300">
                  Vietnam 7D/6N
                </span>
                <h4 className="font-display font-bold text-lg">Golden Bridge & Da Nang</h4>
              </div>
            </div>
          </div>

          <div className="md:col-span-4 cos-glass p-3 rounded-3xl cos-card group shadow-sm">
            <div className="relative h-64 rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=900&q=80"
                alt="Alleppey Backwaters Kerala"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-300">
                  Kerala 12D/11N
                </span>
                <h4 className="font-display font-bold text-lg">Munnar & Alleppey Backwaters</h4>
              </div>
            </div>
          </div>

          <div className="md:col-span-3 cos-glass p-3 rounded-3xl cos-card group shadow-sm">
            <div className="relative h-64 rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1596422846543-75c6fc197f07?auto=format&fit=crop&w=900&q=80"
                alt="Petronas Twin Towers Malaysia"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="text-[10px] font-bold uppercase tracking-widest text-purple-300">
                  Malaysia 6D/5N
                </span>
                <h4 className="font-display font-bold text-lg">KL & Langkawi Island</h4>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. INTERACTIVE DAY-BY-DAY ROUTE VISUALIZER */}
      <section id="route-map" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 scroll-mt-20">
        <RouteVisualizer />
      </section>

      {/* 7. INTERACTIVE TRIP BUDGET ESTIMATOR */}
      <section id="budget-simulator" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 scroll-mt-20">
        <BudgetEstimator />
      </section>

      {/* 8. ABOUT US & SERVICES SECTION */}
      <section id="about-services" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 scroll-mt-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-12">
          <div className="lg:col-span-6 space-y-4">
            <span className="px-3.5 py-1.5 rounded-full cos-glass text-xs font-bold uppercase tracking-widest text-blue-600">
              About Travel O' Friend • চলে আসুন আমাদের অফিসে
            </span>
            <h2 className="font-display font-bold text-3xl sm:text-5xl text-slate-900 leading-tight">
              Kalyani's Premier Hub for{' '}
              <span className="font-serif-italic font-normal text-purple-600">
                Budget & Luxury Travel.
              </span>
            </h2>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-medium">
              Headquartered at <strong className="text-slate-900">B-1/222, Kalyani, Nadia, West Bengal, Pin - 741235</strong>, Travel O' Friend makes your dream vacations come true right within your budget (<span className="text-purple-600 font-semibold">সেরা ভ্রমণ, সেরা অভিজ্ঞতা - একদম আপনার বাজেটে!</span>). Every domestic tour includes daily breakfast, lunch & dinner, sleeper class train tickets, 3-star hotels, complete sightseeing, and all pickups & drops.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <a href="#reviews-contact" className="cos-gradient-btn px-6 py-3 rounded-full text-xs font-bold">
                Visit Office: B-1/222, Kalyani
              </a>
              <button
                type="button"
                onClick={() =>
                  openWhatsApp(
                    'Hello Travel O Friend! I want to enquire about your Domestic & International Tour Packages.'
                  )
                }
                className="px-6 py-3 rounded-full bg-white border border-slate-200 text-slate-900 text-xs font-bold hover:bg-slate-50 shadow-sm"
              >
                WhatsApp Instant Desk
              </button>
            </div>
          </div>

          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="cos-glass p-6 rounded-3xl cos-card shadow-sm">
              <div className="w-12 h-12 liquid-dew-badge text-purple-600 flex items-center justify-center mb-4">
                <Utensils className="w-5 h-5" />
              </div>
              <h3 className="font-display font-bold text-lg text-slate-900">Daily 3 Meals Included</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                প্রতিদিন লাঞ্চ ডিনার ও ব্রেকফাস্ট — Fresh, hygienic, home-style meals included across all 14 domestic tour packages.
              </p>
            </div>

            <div className="cos-glass p-6 rounded-3xl cos-card shadow-sm">
              <div className="w-12 h-12 liquid-dew-badge text-cyan-600 flex items-center justify-center mb-4">
                <TrainFront className="w-4 h-4" />
              </div>
              <h3 className="font-display font-bold text-lg text-slate-900">Train Tickets & Transfers</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                স্লিপার ক্লাস ট্রেন টিকিট ও সমস্ত পিক অ্যান্ড ড্রপ — Confirmed Sleeper Class rail reservations and end-to-end station transfers.
              </p>
            </div>

            <div className="cos-glass p-6 rounded-3xl cos-card shadow-sm">
              <div className="w-12 h-12 liquid-dew-badge text-amber-600 flex items-center justify-center mb-4">
                <Building2 className="w-5 h-5" />
              </div>
              <h3 className="font-display font-bold text-lg text-slate-900">3-Star Hotels & Sightseeing</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                ৩ স্টার হোটেল ও সাইটসিন — Comfortable 3-star family stays and guided local sightseeing in every destination.
              </p>
            </div>

            <div className="cos-glass p-6 rounded-3xl cos-card shadow-sm">
              <div className="w-12 h-12 liquid-dew-badge text-emerald-600 flex items-center justify-center mb-4">
                <Globe className="w-5 h-5" />
              </div>
              <h3 className="font-display font-bold text-lg text-slate-900">Global Visa & Flight Care</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Seamless international packages to Vietnam, Malaysia, Thailand, Bali, and Dubai with complete visa & air-ticket assistance.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 9. TESTIMONIALS & CONTACT / CALLBACK FORM */}
      <section id="reviews-contact" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 scroll-mt-20">
        {/* Verified Traveler Testimonials */}
        <div className="mb-14">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="px-3.5 py-1.5 rounded-full cos-glass text-xs font-bold uppercase tracking-widest text-purple-600">
              Traveler Stories
            </span>
            <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900 mt-3">
              Loved by Families Across Bengal & Beyond
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="cos-glass p-6 rounded-3xl cos-card flex flex-col justify-between shadow-sm">
              <div>
                <div className="flex items-center gap-1 text-amber-500 text-sm mb-3">★★★★★</div>
                <p className="text-sm text-slate-700 leading-relaxed italic">
                  "We booked the 10D/9N Kashmir package at the ₹12,999/- offer price from their B-1/222 Kalyani office. Train tickets, 3-star hotels, daily breakfast-lunch-dinner, and sightseeing were all included as promised!"
                </p>
              </div>
              <div className="flex items-center justify-between pt-4 mt-5 border-t border-white">
                <div>
                  <h4 className="font-display font-bold text-sm text-slate-900">Subhajit & Moumita Roy</h4>
                  <span className="text-[11px] text-slate-500">Kalyani, Nadia • Kashmir 10D/9N</span>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-purple-100 text-purple-700 text-[10px] font-bold">
                  Verified
                </span>
              </div>
            </div>

            <div className="cos-glass p-6 rounded-3xl cos-card flex flex-col justify-between shadow-sm">
              <div>
                <div className="flex items-center gap-1 text-amber-500 text-sm mb-3">★★★★★</div>
                <p className="text-sm text-slate-700 leading-relaxed italic">
                  "Darjeeling 5D/4N at ₹4,999/- per person and Vizag-Araku at ₹8,999/- are unbeatable deals! Great Bengali food and super supportive tour managers throughout the journey."
                </p>
              </div>
              <div className="flex items-center justify-between pt-4 mt-5 border-t border-white">
                <div>
                  <h4 className="font-display font-bold text-sm text-slate-900">Priyanka Sen & Family</h4>
                  <span className="text-[11px] text-slate-500">Barrackpore • Darjeeling & Vizag</span>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-cyan-100 text-cyan-700 text-[10px] font-bold">
                  Verified
                </span>
              </div>
            </div>

            <div className="cos-glass p-6 rounded-3xl cos-card flex flex-col justify-between shadow-sm">
              <div>
                <div className="flex items-center gap-1 text-amber-500 text-sm mb-3">★★★★★</div>
                <p className="text-sm text-slate-700 leading-relaxed italic">
                  "Booked the 7D/6N Grand Vietnam tour (Da Nang, Ba Na Hills Golden Bridge & Hoi An) with Travel O' Friend. Visa, flights, and 4-star stays were handled with 100% transparency."
                </p>
              </div>
              <div className="flex items-center justify-between pt-4 mt-5 border-t border-white">
                <div>
                  <h4 className="font-display font-bold text-sm text-slate-900">Dr. Anirban Chatterjee</h4>
                  <span className="text-[11px] text-slate-500">Salt Lake, Kolkata • Vietnam 7D/6N</span>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-sky-100 text-blue-700 text-[10px] font-bold">
                  Verified
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Office Details & Booking / Callback Form */}
        <div className="cos-glass-strong rounded-3xl p-6 sm:p-10 lg:p-12 shadow-xl border-2 border-white">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-5 space-y-5">
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-rose-500/15 text-rose-700 text-xs font-extrabold uppercase tracking-wider">
                <Building2 className="w-3.5 h-3.5" /> Visit Our Office • আজই বুক করুন!
              </span>
              <h3 className="font-display font-bold text-3xl sm:text-4xl text-slate-900">
                Book Your Dream Tour{' '}
                <span className="font-serif-italic font-normal text-purple-600">Today!</span>
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed font-medium">
                Drop by our Kalyani office or send your preferred destination on WhatsApp for instant seat booking, customized group pricing, and full PDF itineraries.
              </p>

              <div className="space-y-3 pt-1 text-xs font-semibold text-slate-700">
                <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white/90 border border-white shadow-sm">
                  <MapPin className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-rose-600 block">
                      OFFICIAL OFFICE ADDRESS
                    </span>
                    <span className="text-sm font-bold text-slate-900">
                      B-1/222, Kalyani, Nadia, West Bengal, Pin - 741235
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white/90 border border-white shadow-sm">
                  <PhoneCall className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-blue-600 block">
                      24/7 HELPLINE NUMBERS
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 text-sm font-bold text-slate-900 mt-0.5">
                      <a href="tel:+918017559717" className="hover:text-purple-600">
                        +91 80175 59717
                      </a>
                      <a href="tel:+916290681574" className="hover:text-purple-600">
                        +91 62906 81574
                      </a>
                      <a href="tel:+918100260317" className="hover:text-purple-600">
                        +91 81002 60317
                      </a>
                      <a href="tel:+918240747501" className="hover:text-purple-600">
                        +91 82407 47501
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-white/90 border border-white shadow-sm">
                  <Mail className="w-5 h-5 text-purple-600 shrink-0" />
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-purple-600 block">
                      OFFICIAL EMAIL
                    </span>
                    <a
                      href="mailto:travelofriend@gmail.com"
                      className="text-sm font-bold text-slate-900 hover:text-purple-600"
                    >
                      travelofriend@gmail.com
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Callback Form */}
            <form
              onSubmit={handleCallbackSubmit}
              className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white/70 p-6 sm:p-8 rounded-3xl border border-white shadow-md"
            >
              <div>
                <label htmlFor="cbName" className="block text-xs font-bold text-slate-600 mb-1.5">
                  Your Full Name *
                </label>
                <input
                  id="cbName"
                  type="text"
                  required
                  value={cbName}
                  onChange={e => setCbName(e.target.value)}
                  placeholder="e.g., Rahul Banerjee"
                  className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-sm font-semibold text-slate-900 focus:outline-none focus:border-purple-600"
                />
              </div>

              <div>
                <label htmlFor="cbPhone" className="block text-xs font-bold text-slate-600 mb-1.5">
                  WhatsApp / Phone Number *
                </label>
                <input
                  id="cbPhone"
                  type="tel"
                  required
                  value={cbPhone}
                  onChange={e => setCbPhone(e.target.value)}
                  placeholder="+91 98XXX XXXXX"
                  className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-sm font-semibold text-slate-900 focus:outline-none focus:border-purple-600"
                />
              </div>

              <div>
                <label htmlFor="cbDestination" className="block text-xs font-bold text-slate-600 mb-1.5">
                  Select Tour Package *
                </label>
                <select
                  id="cbDestination"
                  value={cbPackage}
                  onChange={e => setCbPackage(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-sm font-semibold text-slate-900 focus:outline-none focus:border-purple-600"
                >
                  <optgroup label="PART 01: DOMESTIC TOURS (14 Places)">
                    <option value="Darjeeling (5D/4N) — Offer ₹4,999/-">1. Darjeeling (5D/4N) — ₹4,999/-</option>
                    <option value="Kashmir (10D/9N) — Offer ₹12,999/-">2. Kashmir (10D/9N) — ₹12,999/-</option>
                    <option value="Haridwar, Mussoorie, Rishikesh & Dehradun (8D/7N) — Offer ₹9,999/-">
                      3. Haridwar, Mussoorie, Rishikesh & Dehradun (8D/7N) — ₹9,999/-
                    </option>
                    <option value="Goa (9D/8N) — Offer ₹14,999/-">4. Goa (9D/8N) — ₹14,999/-</option>
                    <option value="Shimla, Kullu & Manali (10D/9N) — Offer ₹12,999/-">
                      5. Shimla, Kullu & Manali (10D/9N) — ₹12,999/-
                    </option>
                    <option value="Meghalaya & Guwahati (8D/7N) — Offer ₹16,999/-">
                      6. Meghalaya & Guwahati (8D/7N) — ₹16,999/-
                    </option>
                    <option value="Meghalaya, Guwahati & Kaziranga (9D/8N) — Offer ₹19,999/-">
                      7. Meghalaya, Guwahati & Kaziranga (9D/8N) — ₹19,999/-
                    </option>
                    <option value="Andaman (7D/6N) — Offer ₹24,999/- (Flight Extra)">
                      8. Andaman (7D/6N) — ₹24,999/-
                    </option>
                    <option value="Spiti Valley (13D/12N) — Offer ₹28,999/-">
                      9. Spiti Valley (13D/12N) — ₹28,999/-
                    </option>
                    <option value="Arunachal Pradesh (10D/9N) — Offer ₹23,999/-">
                      10. Arunachal Pradesh (10D/9N) — ₹23,999/-
                    </option>
                    <option value="Kerala (12D/11N) — Offer ₹23,999/-">11. Kerala (12D/11N) — ₹23,999/-</option>
                    <option value="Rajasthan (14D/13N) — Offer ₹28,999/-">
                      12. Rajasthan (14D/13N) — ₹28,999/-
                    </option>
                    <option value="Leh Ladakh, Srinagar & Kargil (14D/13N) — Offer ₹36,999/-">
                      13. Leh Ladakh, Srinagar & Kargil (14D/13N) — ₹36,999/-
                    </option>
                    <option value="Vizag & Araku Valley (6D/5N) — Offer ₹8,999/-">
                      14. Vizag & Araku Valley (6D/5N) — ₹8,999/-
                    </option>
                  </optgroup>
                  <optgroup label="PART 02: INTERNATIONAL TOURS (11 Packages)">
                    <option value="Bali (6D/5N) — ₹49,999/- PP (+Flight Extra)">1. Bali (6D/5N) — ₹49,999/-</option>
                    <option value="Kuala Lumpur (4D/3N) — ₹30,999/- PP (+Flight Extra)">
                      2. Kuala Lumpur (4D/3N) — ₹30,999/-
                    </option>
                    <option value="Kuala Lumpur & Langkawi (6D/5N) — ₹44,999/- PP (+Flight Extra)">
                      3. Kuala Lumpur & Langkawi (6D/5N) — ₹44,999/-
                    </option>
                    <option value="Singapore (4D/3N ₹59,999/- | 5D/4N ₹69,999/-)">
                      4. Singapore (4D/3N ₹59,999/- | 5D/4N ₹69,999/-)
                    </option>
                    <option value="Bangkok & Pattaya (4D/3N ₹26,999/- | 5D/4N ₹30,999/-)">
                      5. Bangkok & Pattaya (4D/3N ₹26,999/- | 5D/4N ₹30,999/-)
                    </option>
                    <option value="Phuket & Krabi (5D/4N ₹35,999/- | 6D/5N ₹39,999/-)">
                      6. Phuket & Krabi (5D/4N ₹35,999/- | 6D/5N ₹39,999/-)
                    </option>
                    <option value="Bangkok, Pattaya, Phuket & Krabi (6D/5N) — ₹65,999/- PP">
                      7. Bangkok, Pattaya, Phuket & Krabi (6D/5N) — ₹65,999/-
                    </option>
                    <option value="Vietnam (5D/4N ₹49,999/- | 8D/7N ₹69,999/-)">
                      8. Vietnam (5D/4N ₹49,999/- | 8D/7N ₹69,999/-)
                    </option>
                    <option value="Dubai & Abu Dhabi (5D/4N ₹59,999/- | 6D/5N ₹69,999/-)">
                      9. Dubai & Abu Dhabi (5D/4N ₹59,999/- | 6D/5N ₹69,999/-)
                    </option>
                    <option value="Sri Lanka (8D/7N) — ₹66,999/- PP (+Flight Extra)">
                      10. Sri Lanka (8D/7N) — ₹66,999/-
                    </option>
                    <option value="Phu Quoc Island (4D/3N ₹48,999/- | 5D/4N ₹54,999/-)">
                      11. Phu Quoc Island (4D/3N ₹48,999/- | 5D/4N ₹54,999/-)
                    </option>
                  </optgroup>
                </select>
              </div>

              <div>
                <label htmlFor="cbTravelers" className="block text-xs font-bold text-slate-600 mb-1.5">
                  Travelers & Preferred Month
                </label>
                <input
                  id="cbTravelers"
                  type="text"
                  value={cbTravelers}
                  onChange={e => setCbTravelers(e.target.value)}
                  placeholder="e.g., 2 Adults (Min 2 Pax) • Nov/Dec"
                  className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-sm font-semibold text-slate-900 focus:outline-none focus:border-purple-600"
                />
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="cbNotes" className="block text-xs font-bold text-slate-600 mb-1.5">
                  Special Requests (Optional)
                </label>
                <input
                  id="cbNotes"
                  type="text"
                  value={cbNotes}
                  onChange={e => setCbNotes(e.target.value)}
                  placeholder="e.g., Enquiring about upcoming International Tour batch dates..."
                  className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-sm font-semibold text-slate-900 focus:outline-none focus:border-purple-600"
                />
              </div>

              <div className="sm:col-span-2 pt-2">
                <button
                  type="submit"
                  className="cos-gradient-btn w-full py-4 rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Booking Inquiry to WhatsApp (+91 80175 59717)</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* 10. MODERN GLASSMORPHISM FOOTER */}
      <footer className="cos-glass-strong border-t border-white mt-14 pt-14 pb-10 px-4 sm:px-6 lg:px-8 rounded-t-[3rem] shadow-2xl">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-10 pb-10 border-b border-slate-200/70">
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-3.5">
              <BrandLogo size="lg" />
              <div>
                <span className="font-display font-bold text-2xl text-slate-900 block">
                  Travel <span className="text-purple-600">O' Friend</span>
                </span>
                <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                  স্বপ্ন নয়, এবার সত্যি করুন ঘুরে দেখার ইচ্ছেগুলো!
                </span>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              <strong>Office Address (চলে আসুন আমাদের অফিসে):</strong>
              <br />
              B-1/222, Kalyani, Nadia, West Bengal, Pin - 741235
              <br />
              <strong>Email:</strong>{' '}
              <a href="mailto:travelofriend@gmail.com" className="text-purple-600 font-bold">
                travelofriend@gmail.com
              </a>
              <br />
              <strong>Helplines:</strong> +91 80175 59717 | +91 62906 81574 | +91 81002 60317 | +91 82407 47501
            </p>
          </div>

          <div className="md:col-span-5 space-y-2.5">
            <h4 className="font-display font-bold text-xs uppercase tracking-widest text-purple-600">
              Part 01: All 14 Domestic Flyer Tours
            </h4>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs font-semibold text-slate-600">
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'darjeeling');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                1. Darjeeling (5D) ₹4,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'kashmir');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                2. Kashmir (10D) ₹12,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'haridwar');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                3. Haridwar-Mussoorie ₹9,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'goa');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                4. Goa (9D/8N) ₹14,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'shimla');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                5. Shimla-Manali ₹12,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'meghalaya');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                6. Meghalaya-Guwahati ₹16,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'kaziranga');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                7. Kaziranga Combo ₹19,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'andaman');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                8. Andaman (7D/6N) ₹24,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'spiti');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                9. Spiti Valley (13D) ₹28,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'arunachal');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                10. Arunachal (10D) ₹23,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'kerala');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                11. Kerala (12D) ₹23,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'rajasthan');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                12. Rajasthan (14D) ₹28,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'ladakh');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                13. Leh Ladakh ₹36,999
              </a>
              <a
                href="#domestic-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'vizag');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                14. Vizag-Araku ₹8,999
              </a>
            </div>
          </div>

          <div className="md:col-span-3 space-y-2.5">
            <h4 className="font-display font-bold text-xs uppercase tracking-widest text-blue-600">
              Part 02: International (11)
            </h4>
            <div className="grid grid-cols-1 gap-y-1.5 text-xs font-semibold text-slate-600">
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'bali');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                1. Bali (6D/5N) ₹49,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'kualalumpur');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                2. Kuala Lumpur (4D) ₹30,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'malaysia');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                3. KL & Langkawi ₹44,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'singapore');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                4. Singapore (4D/5D) ₹59,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'bangkok');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                5. Bangkok & Pattaya ₹26,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'thailand');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                6. Phuket & Krabi ₹35,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'allthailand');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                7. Grand Thailand (4-in-1) ₹65,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'vietnam');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                8. Vietnam (5D/8D) ₹49,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'dubai');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                9. Dubai & Abu Dhabi ₹59,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'srilanka');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                10. Sri Lanka (8D/7N) ₹66,999
              </a>
              <a
                href="#international-tours"
                onClick={() => {
                  const p = PACKAGES_DATA.find(i => i.id === 'phuquoc');
                  if (p) setActiveItineraryPackage(p);
                }}
                className="hover:text-slate-900"
              >
                11. Phu Quoc (4D/5D) ₹48,999
              </a>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-6 flex flex-col sm:flex-row items-center justify-between text-xs font-semibold text-slate-500 gap-2">
          <p>© 2026 Travel O' Friend • B-1/222, Kalyani, Nadia, West Bengal, Pin - 741235 • travelofriend@gmail.com</p>
          <p>Luxury & Budget Travel Experience</p>
        </div>
      </footer>

      {/* 11. MODALS & DRAWERS */}
      <StoryViewerModal
        isOpen={activeStoryIndex !== null}
        initialIndex={activeStoryIndex ?? 0}
        onClose={() => setActiveStoryIndex(null)}
        onBookStory={storyId => {
          const pkg = PACKAGES_DATA.find(p => p.id === storyId);
          if (pkg) handleBookPackage(pkg);
        }}
      />

      <ItineraryModal
        isOpen={activeItineraryPackage !== null}
        pkg={activeItineraryPackage}
        onClose={() => setActiveItineraryPackage(null)}
        onBook={handleBookPackage}
      />

      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        savedPackages={savedPackages}
        onRemove={toggleSavePackage}
        onSendWhatsApp={handleSendWishlist}
      />
    </div>
  );
}
