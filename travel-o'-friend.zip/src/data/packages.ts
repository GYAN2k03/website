export interface TourPackage {
  id: string;
  part: 'domestic' | 'international';
  category: 'Himalayas' | 'Northeast' | 'Beach' | 'RoyalSouth' | 'Thailand' | 'Malaysia' | 'Vietnam' | 'SingaporeBali' | 'DubaiSrilanka';
  title: string;
  bengaliName: string;
  duration: string;
  oldPrice?: number;
  price: number;
  tierOptions?: string;
  scarcity: string;
  extraNote: string;
  image: string;
  overview: string;
  highlights: string[];
  itinerary: string[];
}

export const PACKAGES_DATA: TourPackage[] = [
  // ==================== PART 01: DOMESTIC TOURS (14 FLYER PACKAGES) ====================
  {
    id: 'darjeeling',
    part: 'domestic',
    category: 'Himalayas',
    title: 'Darjeeling Queen of Hills (দার্জিলিং)',
    bengaliName: 'দার্জিলিং • ৫ দিন | ৪ রাত',
    duration: '5 Days | 4 Nights',
    oldPrice: 7900,
    price: 4999,
    scarcity: 'Save ₹2,901/- • Mega Flyer Deal',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=900&q=80',
    overview: 'Experience the Queen of Hills within your budget! Includes Sleeper Class train tickets, 3-star hotel stay, daily breakfast, lunch & dinner, Tiger Hill sunrise, Batasia Loop, and all pickups & drops.',
    highlights: ['Tiger Hill Kanchenjunga Sunrise', 'Batasia Loop & Ghoom Monastery', 'Tea Garden & Peace Pagoda', 'Train + 3★ Hotel + 3 Meals/Day'],
    itinerary: [
      'Day 1: Board Sleeper Class train & arrival pickup at NJP Station. Scenic hill transfer to Darjeeling 3-Star Hotel.',
      'Day 2: Early morning Tiger Hill sunrise over Mt. Kanchenjunga, Batasia Loop & Ghoom Monastery.',
      'Day 3: Full-day Darjeeling sightseeing — Padmaja Naidu Zoo, HMI, Tenzing Rock, Tea Estate & Japanese Peace Pagoda.',
      'Day 4: Mirik Lake / Pine Forest excursion & evening stroll at Darjeeling Mall Road (Chowrasta).',
      'Day 5: Morning breakfast & drop to NJP Railway Station for return journey.'
    ]
  },
  {
    id: 'kashmir',
    part: 'domestic',
    category: 'Himalayas',
    title: 'Magnificent Kashmir (কাশ্মীর)',
    bengaliName: 'কাশ্মীর • ১০ দিন | ৯ রাত',
    duration: '10 Days | 9 Nights',
    oldPrice: 15999,
    price: 12999,
    scarcity: 'Save ₹3,000/- • Bestseller Batch',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1595815771614-ade9d652a65d?auto=format&fit=crop&w=900&q=80',
    overview: 'Our flagship 10-day heaven-on-earth Kashmir tour covering Srinagar Dal Lake, Mughal Gardens, Gulmarg snow point, Sonmarg glacier meadow, and Pahalgam Lidder Valley with all meals & train tickets included.',
    highlights: ['Srinagar Dal Lake & Mughal Gardens', 'Gulmarg Snow Meadow Excursion', 'Sonmarg & Pahalgam Betaab Valley', 'Train + 3★ Hotel + Daily Meals'],
    itinerary: [
      'Day 1–2: Train journey from Kolkata/Kalyani to Jammu Tawi & scenic mountain transfer to Srinagar.',
      'Day 3–4: Srinagar sightseeing — Nishat Bagh, Shalimar Bagh, Chashme Shahi, Shankaracharya Temple & Dal Lake Shikara.',
      'Day 5: Full-day excursion to Sonmarg (Meadow of Gold) & Thajiwas Glacier viewpoint.',
      'Day 6: Excursion to Gulmarg (Meadow of Flowers) with Gondola cable car snow point option.',
      'Day 7–8: Transfer to Pahalgam via Pampore Saffron fields & Awantipora ruins; explore Lidder River.',
      'Day 9–10: Return transfer to Jammu railway station & train journey home.'
    ]
  },
  {
    id: 'haridwar',
    part: 'domestic',
    category: 'Himalayas',
    title: 'Haridwar, Mussoorie, Rishikesh & Dehradun',
    bengaliName: 'হরিদ্বার, মুসৌরি, ঋষিকেশ, দেরাদুন • ৮ দিন | ৭ রাত',
    duration: '8 Days | 7 Nights',
    oldPrice: 12999,
    price: 9999,
    scarcity: 'Save ₹3,000/- • Devbhoomi Circuit',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=900&q=80',
    overview: 'Complete Uttarakhand spiritual & hill station tour combining Har Ki Pauri Ganga Aarti in Haridwar, Ram Jhula & Laxman Jhula in Rishikesh, Dehradun valley, and Kempty Falls in Queen of Hills Mussoorie.',
    highlights: ['Har Ki Pauri Evening Ganga Aarti', 'Rishikesh Ram Jhula & Triveni Ghat', 'Mussoorie Kempty Falls & Gun Hill', 'Dehradun Sahastradhara Sightseeing'],
    itinerary: [
      'Day 1–2: Sleeper Class train to Haridwar, hotel check-in & evening Ganga Aarti at Har Ki Pauri.',
      'Day 3: Haridwar Mansa Devi & Chandi Devi temples, then excursion to Rishikesh (Ram Jhula, Parmarth Niketan).',
      'Day 4–5: Drive via Dehradun (Robbers Cave / Sahastradhara) to Mussoorie; visit Kempty Falls & Mall Road.',
      'Day 6: Mussoorie Company Garden, Camel Back Road & return to Haridwar.',
      'Day 7–8: Board return train from Haridwar with cherished memories.'
    ]
  },
  {
    id: 'goa',
    part: 'domestic',
    category: 'Beach',
    title: 'Sun-Kissed Goa Beach Holiday (গোয়া)',
    bengaliName: 'গোয়া • ৯ দিন | ৮ রাত',
    duration: '9 Days | 8 Nights',
    oldPrice: 17900,
    price: 14999,
    scarcity: 'Save ₹2,901/- • North & South Goa',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=900&q=80',
    overview: 'Vibrant 9-day North & South Goa coastal vacation covering Calangute, Baga, Anjuna, Fort Aguada, Old Goa Basilica of Bom Jesus, Miramar Beach, Dona Paula, and Mandovi River sunset.',
    highlights: ['Baga, Calangute & Anjuna Beaches', 'Fort Aguada & Chapora Fort', 'Old Goa Churches & Mangueshi Temple', 'Colva Beach, Dona Paula & Miramar'],
    itinerary: [
      'Day 1–2: Sleeper train journey to Madgaon/Vasco & transfer to 3-star Goa hotel.',
      'Day 3–4: North Goa Tour — Fort Aguada, Sinquerim, Calangute, Baga Beach, Anjuna & Vagator.',
      'Day 5–6: South Goa Heritage Tour — Basilica of Bom Jesus, Se Cathedral, Dona Paula, Miramar & Mandovi Cruise point.',
      'Day 7: Leisure beach day for water sports & coastal market shopping.',
      'Day 8–9: Station drop & return train journey.'
    ]
  },
  {
    id: 'shimla',
    part: 'domestic',
    category: 'Himalayas',
    title: 'Shimla, Kullu & Manali (শিমলা, কুলু ও মানালি)',
    bengaliName: 'শিমলা, কুলু ও মানালি • ১০ দিন | ৯ রাত',
    duration: '10 Days | 9 Nights',
    oldPrice: 16999,
    price: 12999,
    scarcity: 'Save ₹4,000/- • Snow & Apple Valleys',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=900&q=80',
    overview: 'Best-selling Himachal circuit featuring Shimla Ridge & Kufri snow viewpoint, scenic Kullu Shawl Factory & Beas river rafting point, Manali Hadimba Temple, Vashisht Hot Springs, and Solang Valley.',
    highlights: ['Shimla Mall Road, Ridge & Kufri', 'Kullu Valley & Pandoh Dam', 'Manali Hadimba Temple & Club House', 'Solang Valley & Atal Tunnel Point'],
    itinerary: [
      'Day 1–2: Sleeper train journey & uphill drive to Shimla; check-in at 3-Star Hotel.',
      'Day 3: Excursion to Kufri Fun World, Green Valley & Shimla Ridge, Christ Church & Mall Road.',
      'Day 4: Scenic drive from Shimla to Manali via Sundernagar Lake, Pandoh Dam & Kullu Valley.',
      'Day 5–6: Manali local tour (Hadimba Devi Temple, Vashisht Bath, Tibetan Monastery) & full-day Solang Valley.',
      'Day 7–8: Kullu Naggar Castle / rafting viewpoint & return transfer towards railway station.',
      'Day 9–10: Return train journey to Kolkata/Kalyani.'
    ]
  },
  {
    id: 'meghalaya',
    part: 'domestic',
    category: 'Northeast',
    title: 'Meghalaya & Guwahati (মেঘালয় গুয়াহাটি)',
    bengaliName: 'মেঘালয় গুয়াহাটি • ৮ দিন | ৭ রাত',
    duration: '8 Days | 7 Nights',
    oldPrice: 19900,
    price: 16999,
    scarcity: 'Save ₹2,901/- • Scotland of the East',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=900&q=80',
    overview: 'Magical clouds and waterfalls tour covering Guwahati Maa Kamakhya Temple, Umiam Lake, Shillong Peak, Cherrapunji Seven Sisters & Nohkalikai Waterfalls, Mawsmai Cave, Dawki crystal river, and Mawlynnong.',
    highlights: ['Guwahati Maa Kamakhya Temple', 'Shillong Umiam Lake & Elephanta Falls', 'Cherrapunji Nohkalikai & Caves', 'Dawki Umngot River & Mawlynnong'],
    itinerary: [
      'Day 1–2: Train to Guwahati & scenic ascent to Shillong via Umiam (Barapani) Lake.',
      'Day 3: Excursion to Cherrapunji (Sohra) — Nohkalikai Falls, Seven Sisters Falls, Mawsmai Cave & Eco Park.',
      'Day 4: Dawki crystal-clear Umngot River boating & Mawlynnong (Asias Cleanest Village) + Single Root Bridge.',
      'Day 5–6: Shillong Ward Lake, Don Bosco Museum & drive down to Guwahati for Maa Kamakhya Temple darshan.',
      'Day 7–8: Brahmaputra riverfront & return train journey.'
    ]
  },
  {
    id: 'kaziranga',
    part: 'domestic',
    category: 'Northeast',
    title: 'Meghalaya, Guwahati & Kaziranga (মেঘালয় গুয়াহাটি কাজিরাঙা)',
    bengaliName: 'মেঘালয় গুয়াহাটি কাজিরাঙা • ৯ দিন | ৮ রাত',
    duration: '9 Days | 8 Nights',
    oldPrice: 23900,
    price: 19999,
    scarcity: 'Save ₹3,901/- • Wildlife + Waterfalls',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=900&q=80',
    overview: 'Grand Northeast combo combining UNESCO World Heritage Kaziranga National Park (One-Horned Rhino habitat) with Shillong, Cherrapunji waterfalls, Dawki emerald river, Mawlynnong, and Guwahati Kamakhya Temple.',
    highlights: ['Kaziranga National Park Jungle Trail', 'Cherrapunji Waterfalls & Caves', 'Dawki River & Living Root Bridge', 'Guwahati Kamakhya & Brahmaputra'],
    itinerary: [
      'Day 1–2: Train arrival at Guwahati & drive to Kaziranga National Park; check-in to resort.',
      'Day 3: Early morning Kaziranga Jungle Safari (Jeep/Elephant option) & transfer to Shillong via Umiam Lake.',
      'Day 4: Cherrapunji excursion — Wakaba Falls, Nohkalikai Falls, Mawsmai Cave & Seven Sisters Falls.',
      'Day 5: Dawki Indo-Bangladesh border, Umngot River & Mawlynnong Cleanest Village.',
      'Day 6–7: Shillong local sightseeing & transfer to Guwahati for Maa Kamakhya Temple.',
      'Day 8–9: Return sleeper train journey.'
    ]
  },
  {
    id: 'andaman',
    part: 'domestic',
    category: 'Beach',
    title: 'Tropical Andaman Islands (আন্দামান)',
    bengaliName: 'আন্দামান • ৭ দিন | ৬ রাত (FLIGHT FARE EXTRA)',
    duration: '7 Days | 6 Nights',
    oldPrice: 30900,
    price: 24999,
    scarcity: 'Save ₹5,901/- • Flight Fare Extra',
    extraNote: 'FLIGHT FARE EXTRA • 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=900&q=80',
    overview: 'Complete 7-day emerald island tour covering Port Blair Cellular Jail Light & Sound Show, Ross Island, Coral North Bay, Havelock Island Radhanagar Blue Flag Beach, Elephant Beach, and Neil Island Natural Bridge.',
    highlights: ['Port Blair Cellular Jail & Ross Island', 'Havelock Radhanagar & Elephant Beach', 'Neil Island Laxmanpur & Natural Rock', '3★ Hotels + All Meals + Ferry Transfers'],
    itinerary: [
      'Day 1: Arrival at Port Blair Airport, hotel check-in, Corbyns Cove Beach & Cellular Jail Light & Sound Show.',
      'Day 2: Boat excursion to Ross Island (Netaji Subhash Bose Island) & North Bay Coral Island.',
      'Day 3–4: Cruise transfer to Havelock Island (Swaraj Dweep) — Radhanagar Beach & Elephant Beach water activities.',
      'Day 5: Transfer to Neil Island (Shaheed Dweep) — Bharatpur Beach, Laxmanpur Sunset & Natural Coral Bridge.',
      'Day 6–7: Return to Port Blair, Chidiya Tapu / Sagarika shopping & airport drop (Flight Fare Extra).'
    ]
  },
  {
    id: 'spiti',
    part: 'domestic',
    category: 'Himalayas',
    title: 'Spiti Valley Himalayan Odyssey (স্পিতি ভ্যালি)',
    bengaliName: 'স্পিতি ভ্যালি • ১৩ দিন | ১২ রাত',
    duration: '13 Days | 12 Nights',
    oldPrice: 31900,
    price: 28999,
    scarcity: 'Save ₹2,901/- • Middle Land Expedition',
    extraNote: 'Includes Train + Stays + All Meals',
    image: 'https://images.unsplash.com/photo-1566837945700-30057527ade0?auto=format&fit=crop&w=900&q=80',
    overview: 'Epic 13-day high-altitude trans-Himalayan expedition through Shimla, Sangla, Chitkul (last Indian village), Kalpa Kinnaur Kailash view, Tabo Monastery, Kaza, Key Monastery, Hikkim (worlds highest post office), and Chandratal.',
    highlights: ['Sangla, Chitkul & Kalpa Kinnaur View', 'Kaza, Key Monastery & Kibber Village', 'Hikkim Highest Post Office & Komic', 'Chandratal Moon Lake & Kunzum Pass'],
    itinerary: [
      'Day 1–3: Train journey & ascent via Shimla/Narkanda to Sangla & Chitkul in Kinnaur Valley.',
      'Day 4–5: Kalpa Suicide Point & Kinnaur Kailash view, then enter Spiti via Nako Lake & Gue Mummy Temple to Tabo.',
      'Day 6–8: Kaza hub — Key Monastery, Chicham Bridge, Hikkim (Highest Post Office), Komic & Langza Buddha Statue.',
      'Day 9–10: Cross Kunzum Pass to breathtaking Chandratal Lake & descend via Atal Tunnel to Manali.',
      'Day 11–13: Return transfer & train journey back home.'
    ]
  },
  {
    id: 'arunachal',
    part: 'domestic',
    category: 'Northeast',
    title: 'Arunachal Pradesh & Tawang (অরুণাচল প্রদেশ)',
    bengaliName: 'অরুণাচল প্রদেশ • ১০ দিন | ৯ রাত',
    duration: '10 Days | 9 Nights',
    oldPrice: 28900,
    price: 23999,
    scarcity: 'Save ₹4,901/- • Land of Dawn-Lit Mountains',
    extraNote: 'Includes ILP + Train + 3★ Stays + Meals',
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=900&q=80',
    overview: 'Majestic Eastern Himalayan circuit covering Bhalukpong, Dirang Valley, snow-draped Sela Pass (13,700 ft), Jaswant Garh War Memorial, Tawang Monastery (Indias largest), Madhuri Lake, Bumla Pass option, and Bomdila.',
    highlights: ['Dirang Sangti Valley & Hot Springs', 'Sela Pass (13,700 ft) & Sela Lake', 'Tawang Monastery & War Memorial', 'Madhuri Lake, Nuranang Falls & Bomdila'],
    itinerary: [
      'Day 1–2: Train to Guwahati/Rangapara & drive via Bhalukpong Orchidarium to Dirang.',
      'Day 3–4: Cross high-altitude Sela Pass & Jaswant Garh to reach Tawang.',
      'Day 5–6: Tawang 400-year-old Monastery, Giant Buddha, War Memorial, Sungester (Madhuri) Lake & Nuranang Falls.',
      'Day 7–8: Return via Bomdila Monastery to Guwahati.',
      'Day 9–10: Return sleeper train journey.'
    ]
  },
  {
    id: 'kerala',
    part: 'domestic',
    category: 'RoyalSouth',
    title: 'Grand Kerala Backwaters & Hills (কেরালা)',
    bengaliName: 'কেরালা • ১২ দিন | ১১ রাত',
    duration: '12 Days | 11 Nights',
    oldPrice: 28900,
    price: 23999,
    scarcity: 'Save ₹4,901/- • Complete Gods Own Country',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=900&q=80',
    overview: 'Comprehensive 12-day Kerala tour from Cochin Fort Kochi & Marine Drive to Munnar emerald tea estates, Thekkady Periyar wildlife, Alleppey serene backwaters, Kovalam lighthouse beach, Trivandrum, and Kanyakumari.',
    highlights: ['Cochin Heritage & Munnar Tea Hills', 'Thekkady Periyar Lake & Spice Garden', 'Alleppey Backwaters & Houseboat Point', 'Kovalam Beach & Kanyakumari Vivekananda Rock'],
    itinerary: [
      'Day 1–3: Sleeper train journey to Ernakulam (Cochin) & scenic transfer to Munnar via Cheeyappara Waterfalls.',
      'Day 4–5: Munnar sightseeing (Eravikulam, Mattupetty Dam, Echo Point) & transfer to Thekkady Periyar.',
      'Day 6–7: Alleppey backwater excursion & drive to Kovalam Beach resort.',
      'Day 8–9: Trivandrum Padmanabhaswamy Temple & full-day excursion to Kanyakumari Sunset/Sunrise point.',
      'Day 10–12: Return train journey to Kolkata/Kalyani with all meals.'
    ]
  },
  {
    id: 'rajasthan',
    part: 'domestic',
    category: 'RoyalSouth',
    title: 'Royal Rajasthan Desert & Forts (রাজস্থান)',
    bengaliName: 'রাজস্থান • ১৪ দিন | ১৩ রাত',
    duration: '14 Days | 13 Nights',
    oldPrice: 31990,
    price: 28999,
    scarcity: 'Save ₹2,991/- • Grand Royal Circuit',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=900&q=80',
    overview: 'Grand 14-day royal heritage expedition covering Pink City Jaipur (Amer Fort, Hawa Mahal), Pushkar Brahma Temple, Lake City Udaipur, Mount Abu hill station, Blue City Jodhpur (Mehrangarh), and Golden City Jaisalmer Sam Sand Dunes.',
    highlights: ['Jaipur Amer Fort, City Palace & Hawa Mahal', 'Udaipur Lake Pichola & Mount Abu', 'Jodhpur Mehrangarh Fort & Umaid Bhawan', 'Jaisalmer Golden Fort & Desert Camp'],
    itinerary: [
      'Day 1–3: Train to Jaipur & sightseeing of Amer Fort, Jal Mahal, Hawa Mahal, Jantar Mantar & Birla Mandir.',
      'Day 4–6: Ajmer Dargah, Pushkar Lake & transfer to Udaipur (City Palace, Lake Pichola, Saheliyon Ki Bari).',
      'Day 7–8: Mount Abu Dilwara Jain Temples & Nakki Lake, then proceed to Jodhpur Mehrangarh Fort.',
      'Day 9–11: Jaisalmer Sonar Kella (Golden Fort), Patwon Ki Haveli & Sam Sand Dunes Camel Ride + Folk Dance.',
      'Day 12–14: Return train journey to Kolkata/Kalyani.'
    ]
  },
  {
    id: 'ladakh',
    part: 'domestic',
    category: 'Himalayas',
    title: 'Leh Ladakh, Srinagar & Kargil (লেহ লাদাখ শ্রীনগর কার্গিল)',
    bengaliName: 'লেহ লাদাখ শ্রীনগর কার্গিল • ১৪ দিন | ১৩ রাত',
    duration: '14 Days | 13 Nights',
    oldPrice: 39900,
    price: 36999,
    scarcity: 'Save ₹2,901/- • Trans-Himalayan Crown',
    extraNote: 'Includes Train + Stays + All Meals',
    image: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?auto=format&fit=crop&w=900&q=80',
    overview: 'The ultimate 14-day bucket-list highway journey from Srinagar across Zojila Pass to Kargil War Memorial, Lamayuru Moonland, Leh Palace, Sham Valley (Magnetic Hill, Sangam), Khardungla Top, Nubra Valley, and Pangong Lake.',
    highlights: ['Srinagar, Zojila Pass & Kargil Memorial', 'Leh Shanti Stupa, Magnetic Hill & Sangam', 'Khardungla Pass & Nubra Hunder Dunes', 'Iconic Color-Changing Pangong Tso Lake'],
    itinerary: [
      'Day 1–3: Train to Jammu & transfer to Srinagar; acclimatization & local sightseeing.',
      'Day 4–5: Drive via Sonmarg & Zojila Pass to Drass (Kargil War Memorial), Mulbekh & Lamayuru to Leh.',
      'Day 6–7: Leh Local — Hall of Fame, Pathar Sahib, Magnetic Hill, Indus-Zanskar Sangam & Shanti Stupa.',
      'Day 8–9: Cross Khardungla Pass (17,982 ft) to Nubra Valley (Diskit Monastery & Hunder Double-Humped Camels).',
      'Day 10–11: Excursion to turquoise Pangong Lake (14,270 ft) & return to Leh.',
      'Day 12–14: Return highway/rail transfer back home.'
    ]
  },
  {
    id: 'vizag',
    part: 'domestic',
    category: 'Beach',
    title: 'Vizag & Araku Valley (ভাইজ্যাক আরাকু ভ্যালি)',
    bengaliName: 'ভাইজ্যাক আরাকু ভ্যালি • ৬ দিন | ৫ রাত',
    duration: '6 Days | 5 Nights',
    oldPrice: 11900,
    price: 8999,
    scarcity: 'Save ₹2,901/- • Sea & Coffee Hills',
    extraNote: 'Includes Train + 3★ Hotel + All Meals',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80',
    overview: 'Pocket-friendly 6-day coastal and hill holiday covering Visakhapatnam RK Beach, INS Kurusura Submarine Museum, Kailasagiri Hill, Rushikonda Beach, Simhachalam Temple, Borra Caves, and misty Araku Coffee Valley.',
    highlights: ['RK Beach, Submarine & Aircraft Museum', 'Kailasagiri Ropeway & Rushikonda Beach', 'Million-Year-Old Borra Stalactite Caves', 'Araku Tribal Museum & Coffee Plantations'],
    itinerary: [
      'Day 1–2: Sleeper train to Visakhapatnam, check-in at 3-Star Hotel & evening stroll at RK Beach & Submarine Museum.',
      'Day 3: Vizag Sightseeing — Kailasagiri Hill Park, Rushikonda Beach, Tenneti Park & Simhachalam Temple.',
      'Day 4: Scenic Eastern Ghats journey to Araku Valley via Ananthagiri Waterfalls, Galikonda Viewpoint & Borra Caves.',
      'Day 5: Padmapuram Botanical Gardens & Tribal Museum, then return to Vizag station.',
      'Day 6: Morning arrival back home.'
    ]
  },

  // ==================== PART 02: INTERNATIONAL TOURS (11 FLYER PACKAGES) ====================
  {
    id: 'bali',
    part: 'international',
    category: 'SingaporeBali',
    title: 'Magical Bali Island Escape (বালি)',
    bengaliName: 'বালি • ৬ দিন | ৫ রাত',
    duration: '6 Days | 5 Nights',
    price: 49999,
    tierOptions: '6D/5N: ₹49,999/- PP',
    scarcity: '★ Bestseller Island Escape',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=900&q=80',
    overview: 'Complete 6-day Bali holiday including Daily Breakfast, 3-Star Hotel Accommodation, All Pickup & Drop Services, and All Sightseeing & Entry Fees (Ubud, Kintamani, Uluwatu & Nusa Penida).',
    highlights: ['Ubud Rice Terraces & Jungle Bali Swing', 'Kintamani Volcano & Tirta Empul Temple', 'Nusa Penida Kelingking Cliff Excursion', '3★ Hotel + Breakfast + Entry Fees Included'],
    itinerary: [
      'Day 1–2: Denpasar Airport pickup, check-in to 3-Star Bali Hotel & Ubud Sacred Monkey Forest + Bali Swing.',
      'Day 3: Full-day Kintamani Mount Batur Volcano view, Tegenungan Waterfall & Coffee Plantation.',
      'Day 4: Excursion to Nusa Penida Island (Kelingking T-Rex Bay, Angel Billabong & Broken Beach).',
      'Day 5: Tanah Lot & Uluwatu Sunset Temple with Kecak Fire Dance.',
      'Day 6: Morning breakfast & airport drop (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'kualalumpur',
    part: 'international',
    category: 'Malaysia',
    title: 'Dazzling Kuala Lumpur City Break',
    bengaliName: 'কুয়ালালামপুর • ৪ দিন | ৩ রাত',
    duration: '4 Days | 3 Nights',
    price: 30999,
    tierOptions: '4D/3N: ₹30,999/- PP',
    scarcity: '★ City Highlights Tour',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1596422846543-75c6fc197f07?auto=format&fit=crop&w=900&q=80',
    overview: 'Exciting 4D/3N Kuala Lumpur gateway with Daily Breakfast, 3-Star Hotel Stay, All Pickup & Drop Services, and All Sightseeing & Entry Fees included.',
    highlights: ['Petronas Twin Towers & KL Tower Photo Stop', 'Batu Caves & Genting Highlands Cable Car', 'Putrajaya & Kings Palace City Tour', '3★ Hotel + Breakfast + All Entry Fees'],
    itinerary: [
      'Day 1: Arrival at Kuala Lumpur International Airport, pickup & check-in at 3-Star KL Hotel; evening KL City Tour.',
      'Day 2: Full-day Genting Highlands excursion via Awana SkyWay Cable Car & en-route Batu Caves visit.',
      'Day 3: Kings Palace, Independence Square, National Monument, KL Tower & Bukit Bintang shopping.',
      'Day 4: Breakfast & airport transfer (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'malaysia',
    part: 'international',
    category: 'Malaysia',
    title: 'Kuala Lumpur & Langkawi Island Combo',
    bengaliName: 'কুয়ালালামপুর ও লাঙ্কাউই • ৬ দিন | ৫ রাত',
    duration: '6 Days | 5 Nights',
    price: 44999,
    tierOptions: '6D/5N: ₹44,999/- PP',
    scarcity: '★ Twin Destination Combo',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1508062878650-88b52897f298?auto=format&fit=crop&w=900&q=80',
    overview: 'Best of Malaysia in 6 Days / 5 Nights covering Kuala Lumpur Twin Towers, Genting Highlands, and duty-free Langkawi Island SkyBridge. Includes Daily Breakfast, 3★ Hotel, All Transfers & Entry Fees.',
    highlights: ['Kuala Lumpur Petronas Towers & Batu Caves', 'Genting Highlands SkyWay Cable Car', 'Langkawi SkyBridge, SkyCab & Eagle Square', '3★ Hotel + Breakfast + All Sightseeing Fees'],
    itinerary: [
      'Day 1–2: Kuala Lumpur arrival, 3-Star Hotel stay, KL City Sightseeing & Genting Highlands day excursion.',
      'Day 3: Transfer to Langkawi Island — check-in & Pantai Cenang beach leisure.',
      'Day 4–5: Langkawi Oriental Village Cable Car, SkyBridge, Eagle Square & Island Hopping.',
      'Day 6: Morning breakfast & airport drop (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'singapore',
    part: 'international',
    category: 'SingaporeBali',
    title: 'Futuristic Singapore Lion City Tour',
    bengaliName: 'সিঙ্গাপুর • ৪ দিন/৩ রাত অথবা ৫ দিন/৪ রাত',
    duration: '4D/3N or 5D/4N',
    price: 59999,
    tierOptions: '4D/3N: ₹59,999/- | 5D/4N: ₹69,999/- PP',
    scarcity: '★ Premium City Experience',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?auto=format&fit=crop&w=900&q=80',
    overview: 'Choose 4D/3N (@ ₹59,999/- PP) or 5D/4N (@ ₹69,999/- PP)! Includes Daily Breakfast, 3-Star Hotel Accommodation, All Pickup & Drop Services, and Sightseeing & Entry Fees (Gardens by the Bay, Sentosa Island, Merlion Park).',
    highlights: ['4D/3N @ ₹59,999/- OR 5D/4N @ ₹69,999/-', 'Marina Bay Sands SkyPark & Gardens by the Bay', 'Sentosa Island Cable Car & Wings of Time', 'Merlion Park, Chinatown & Little India'],
    itinerary: [
      'Day 1: Arrival at Singapore Changi Airport, pickup & check-in to 3-Star Hotel; evening Night Safari / Marina Bay.',
      'Day 2: Half-day Singapore City Tour (Merlion Park, Singapore Flyer view, Chinatown) & Afternoon Sentosa Island.',
      'Day 3: Gardens by the Bay (Cloud Forest & Flower Dome) + Supertree Grove Light Show.',
      'Day 4–5: Optional Universal Studios / Orchard Road shopping & airport drop (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'bangkok',
    part: 'international',
    category: 'Thailand',
    title: 'Bangkok & Pattaya Coral Island Getaway',
    bengaliName: 'ব্যাংকক ও পাতায়া • ৪ দিন/৩ রাত অথবা ৫ দিন/৪ রাত',
    duration: '4D/3N or 5D/4N',
    price: 26999,
    tierOptions: '4D/3N: ₹26,999/- | 5D/4N: ₹30,999/- PP',
    scarcity: '★ Budget International Pick',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=900&q=80',
    overview: 'Our most affordable international tour! Choose 4D/3N (@ ₹26,999/- PP) or 5D/4N (@ ₹30,999/- PP). Includes Pattaya Coral Island by speedboat, Alcazar Show, Bangkok Golden & Marble Buddha Temples, 3★ Hotels & Daily Breakfast.',
    highlights: ['4D/3N @ ₹26,999/- OR 5D/4N @ ₹30,999/-', 'Pattaya Coral Island (Koh Larn) Speedboat', 'Alcazar Cabaret Show & Gems Gallery', 'Bangkok Golden Buddha & Chao Phraya'],
    itinerary: [
      'Day 1: Bangkok Airport pickup & scenic transfer to Pattaya 3-Star Hotel; evening Alcazar Show.',
      'Day 2: Speedboat excursion to Coral Island (Koh Larn) with beach time & Pattaya Floating Market.',
      'Day 3: Transfer to Bangkok via Gems Gallery; half-day Bangkok Temple & City Tour (Wat Traimit & Wat Benchamabophit).',
      'Day 4–5: Safari World & Marine Park / Pratunam shopping & airport drop (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'thailand',
    part: 'international',
    category: 'Thailand',
    title: 'Tropical Phuket & Krabi Island Hopping',
    bengaliName: 'ফুকেট ও ক্রাবি • ৫ দিন/৪ রাত অথবা ৬ দিন/৫ রাত',
    duration: '5D/4N or 6D/5N',
    price: 35999,
    tierOptions: '5D/4N: ₹35,999/- | 6D/5N: ₹39,999/- PP',
    scarcity: '★ Tropical Island Hopping',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=900&q=80',
    overview: 'Choose 5D/4N (@ ₹35,999/- PP) or 6D/5N (@ ₹39,999/- PP)! Covers Krabi 4-Islands Tour, Phi Phi Island & Maya Bay Speedboat Cruise, Phuket Big Buddha, Wat Chalong, and Patong Beach with 3★ Hotels, Breakfast & Entry Fees.',
    highlights: ['5D/4N @ ₹35,999/- OR 6D/5N @ ₹39,999/-', 'Krabi 4-Islands Speedboat Excursion', 'Phi Phi Island & Maya Bay Snorkeling', 'Phuket City Tour, Big Buddha & Old Town'],
    itinerary: [
      'Day 1–2: Arrival in Krabi, 3-Star Hotel check-in & full-day Krabi 4-Islands Speedboat Tour.',
      'Day 3: Transfer to Phuket & full-day Phi Phi Island + Maya Bay Speedboat Excursion.',
      'Day 4: Phuket City Tour — Big Buddha, Wat Chalong, Karon Viewpoint & Sino-Portuguese Old Town.',
      'Day 5–6: Leisure beach shopping & Phuket Airport drop (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'allthailand',
    part: 'international',
    category: 'Thailand',
    title: 'Grand Thailand: Bangkok, Pattaya, Phuket & Krabi',
    bengaliName: 'ব্যাংকক, পাতায়া, ফুকেট ও ক্রাবি • ৬ দিন | ৫ রাত',
    duration: '6 Days | 5 Nights',
    price: 65999,
    tierOptions: '6D/5N All-in-One: ₹65,999/- PP',
    scarcity: '★ Complete Mega Circuit',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1528181304800-259b08848526?auto=format&fit=crop&w=900&q=80',
    overview: 'The ultimate 4-destination Thailand mega circuit combining Bangkok, Pattaya Coral Island, Phuket Phi Phi Island, and Krabi 4 Islands in 6 Days / 5 Nights with 3-Star Hotels, Daily Breakfast, Transfers & Sightseeing Fees.',
    highlights: ['Covers All 4: Bangkok, Pattaya, Phuket & Krabi', 'Coral Island + Phi Phi Island + Krabi 4 Islands', 'Bangkok Golden Buddha & Pattaya Viewpoint', '3★ Hotels + Daily Breakfast + Entry Fees'],
    itinerary: [
      'Day 1–2: Arrival in Bangkok, transfer to Pattaya & Coral Island Speedboat Tour.',
      'Day 3: Bangkok Temple Tour & fly to Phuket/Krabi.',
      'Day 4: Krabi 4-Islands Speedboat Excursion & Ao Nang Beach.',
      'Day 5–6: Phi Phi Island Tour, Phuket City Sightseeing & departure airport transfer (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'vietnam',
    part: 'international',
    category: 'Vietnam',
    title: 'Grand Vietnam: Hanoi, Ha Long Bay & Da Nang',
    bengaliName: 'ভিয়েতনাম • ৫ দিন/৪ রাত অথবা ৮ দিন/৭ রাত',
    duration: '5D/4N or 8D/7N',
    price: 49999,
    tierOptions: '5D/4N: ₹49,999/- | 8D/7N: ₹69,999/- PP',
    scarcity: '★ UNESCO Heritage Special',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=900&q=80',
    overview: 'Choose 5D/4N (@ ₹49,999/- PP) or Grand 8D/7N (@ ₹69,999/- PP)! Includes Ha Long Bay Cruise, Ba Na Hills Golden Hands Bridge cable car, Hoi An Lantern Town, Hanoi Old Quarter, 3★ Hotels, Breakfast & Entry Fees.',
    highlights: ['5D/4N @ ₹49,999/- OR 8D/7N @ ₹69,999/-', 'Ba Na Hills Golden Hands Bridge & Cable Car', 'Ha Long Bay Limestone Cruise & Kayaking', 'Hoi An Ancient Town & Cam Thanh Basket Boat'],
    itinerary: [
      'Day 1–2: Hanoi arrival, Old Quarter, Hoan Kiem Lake & full-day Ha Long Bay Luxury Boat Cruise.',
      'Day 3–4: Fly to Da Nang — full-day Ba Na Hills Golden Bridge & Marble Mountains + Hoi An Lantern Town.',
      'Day 5–8: (For 8D/7N Option) Ho Chi Minh City, Mekong Delta & Cu Chi Tunnels before return flight (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'dubai',
    part: 'international',
    category: 'DubaiSrilanka',
    title: 'Royal Dubai & Abu Dhabi Grand Tour',
    bengaliName: 'দুবাই ও আবুধাবি • ৫ দিন/৪ রাত অথবা ৬ দিন/৫ রাত',
    duration: '5D/4N or 6D/5N',
    price: 59999,
    tierOptions: '5D/4N: ₹59,999/- | 6D/5N: ₹69,999/- PP',
    scarcity: '★ Desert & Modern Marvels',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=900&q=80',
    overview: 'Choose 5D/4N (@ ₹59,999/- PP) or 6D/5N (@ ₹69,999/- PP)! Covers Dubai Burj Khalifa 124th Floor, Marina Dhow Cruise, 4x4 Desert Safari with BBQ Dinner, and Abu Dhabi Sheikh Zayed Grand Mosque & Ferrari World photo stop.',
    highlights: ['5D/4N @ ₹59,999/- OR 6D/5N @ ₹69,999/-', 'Burj Khalifa 124th Floor & Dubai Mall Fountain', '4x4 Red Dunes Desert Safari & Marina Cruise', 'Abu Dhabi Grand Mosque & BAPS Mandir'],
    itinerary: [
      'Day 1: Dubai Airport pickup, check-in to 3-Star Hotel & evening Marina Dhow Dinner Cruise.',
      'Day 2: Half-Day Dubai City Tour, Dubai Mall Aquarium view & Burj Khalifa 124th Floor Observation Deck.',
      'Day 3: Afternoon 4x4 Desert Safari Dune Bashing, Camel Ride, Tanoura & Belly Dance with BBQ Dinner.',
      'Day 4–6: Full-day Abu Dhabi Excursion (Sheikh Zayed Grand Mosque, BAPS Hindu Mandir, Yas Island) & Departure (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'srilanka',
    part: 'international',
    category: 'DubaiSrilanka',
    title: 'Emerald Sri Lanka: Kandy, Nuwara Eliya & Bentota',
    bengaliName: 'শ্রীলঙ্কা • ৮ দিন | ৭ রাত',
    duration: '8 Days | 7 Nights',
    price: 66999,
    tierOptions: '8D/7N Complete Circuit: ₹66,999/- PP',
    scarcity: '★ Complete Island Route',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=900&q=80',
    overview: 'Comprehensive 8-Day / 7-Night Sri Lanka island circuit covering Pinnawala Elephant Orphanage, Sigiriya Lion Rock, Kandy Temple of the Sacred Tooth Relic, Nuwara Eliya Ramayana Trail & Tea Hills, Bentota Beach, and Colombo.',
    highlights: ['Sigiriya Rock Fortress & Dambulla Cave Temple', 'Kandy Tooth Relic Temple & Cultural Show', 'Nuwara Eliya Tea Estates & Seetha Amman Temple', 'Bentota Madu River Safari & Colombo Tour'],
    itinerary: [
      'Day 1–2: Colombo Airport pickup, Pinnawala Elephant Orphanage & Sigiriya Lion Rock Fortress.',
      'Day 3–4: Transfer to Kandy — Spice Garden, Temple of the Tooth Relic, Peradeniya Botanical Gardens & Cultural Dance.',
      'Day 5–6: Scenic hill drive to Nuwara Eliya (Ramboda Falls, Tea Factory, Gregory Lake & Seetha Amman Temple).',
      'Day 7–8: Bentota Turtle Hatchery, Madu River Boat Safari, Colombo City Tour & Airport Drop (+ Flight Fare Extra).'
    ]
  },
  {
    id: 'phuquoc',
    part: 'international',
    category: 'Vietnam',
    title: 'Exotic Phu Quoc Island Paradise (Vietnam)',
    bengaliName: 'ফু কোক আইল্যান্ড • ৪ দিন/৩ রাত অথবা ৫ দিন/৪ রাত',
    duration: '4D/3N or 5D/4N',
    price: 48999,
    tierOptions: '4D/3N: ₹48,999/- | 5D/4N: ₹54,999/- PP',
    scarcity: '★ Tropical Island Gem',
    extraNote: '+ FLIGHT FARE EXTRA • 3★ Hotel + B/F',
    image: 'https://images.unsplash.com/photo-1559592413-7cec4d0cae2b?auto=format&fit=crop&w=900&q=80',
    overview: 'Explore Vietnams tropical island gem Phu Quoc! Choose 4D/3N (@ ₹48,999/- PP) or 5D/4N (@ ₹54,999/- PP). Includes Hon Thom Worlds Longest Over-Sea Cable Car, Grand World Venice Canal, VinWonders/Safari, and 4-Island Speedboat Tour.',
    highlights: ['4D/3N @ ₹48,999/- OR 5D/4N @ ₹54,999/-', 'Hon Thom Over-Sea Cable Car & Aquatopia', 'Grand World Phu Quoc Venice Gondola Canal', 'Sunset Town Kiss Bridge & 3-Island Hopping'],
    itinerary: [
      'Day 1: Arrival at Phu Quoc International Airport, check-in to 3-Star Resort & explore Grand World "Sleepless City".',
      'Day 2: South Island 3-Island Speedboat Snorkeling Tour & ride the Worlds Longest Over-Sea Cable Car to Hon Thom.',
      'Day 3: VinWonders Theme Park / Vinpearl Safari & Sunset Town Kiss Bridge.',
      'Day 4–5: Duong Dong Night Market, pearl shopping & airport drop (+ Flight Fare Extra).'
    ]
  }
];
