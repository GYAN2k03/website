export interface RouteCheckpoint {
  day: string;
  title: string;
  weather: string;
  stay: string;
  elev: string;
  meals: string;
  desc: string;
  img: string;
}

export interface RouteTrack {
  heading: string;
  checkpoints: RouteCheckpoint[];
}

export const ROUTE_TRACKS: Record<string, RouteTrack> = {
  kashmir: {
    heading: 'Magnificent Kashmir (10D / 9N) Trail',
    checkpoints: [
      {
        day: 'Days 01–02',
        title: 'Srinagar & Dal Lake Shikara Sanctuary',
        weather: '14°C • Crisp Alpine Breeze',
        stay: 'Deluxe Dal Lake Houseboat',
        elev: '5,200 ft • Valley Floor',
        meals: 'Breakfast, Dinner & Pvt Cab',
        desc: 'Touch down in Srinagar, glide across Dal Lake on a cushioned Shikara to Nehru Park, and stroll through Nishat and Shalimar Mughal Gardens.',
        img: 'https://images.unsplash.com/photo-1595815771614-ade9d652a65d?auto=format&fit=crop&w=1200&q=80'
      },
      {
        day: 'Days 03–05',
        title: 'Sonmarg Glacier & Gulmarg Snow Gondola',
        weather: '4°C • Snow Meadow Panorama',
        stay: '3★/4★ Heated Alpine Resort',
        elev: '8,690 ft • Kongdoori Peak',
        meals: 'All Meals + Gondola Assist',
        desc: 'Ascend to Sonmarg Thajiwas Glacier and ride the world-famous Gulmarg Gondola cable car above pine forests.',
        img: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=1200&q=80'
      },
      {
        day: 'Days 06–10',
        title: 'Pahalgam Lidder River, Aru & Betaab Valley',
        weather: '11°C • Pine & River Mist',
        stay: 'Riverside Pahalgam Resort',
        elev: '7,200 ft • Lidder Valley',
        meals: 'Breakfast, Dinner & Union Cab',
        desc: 'Explore saffron fields at Pampore, Awantipora ruins, and spend leisurely days in Betaab Valley, Aru Valley, and Chandanwari.',
        img: 'https://images.unsplash.com/photo-1566837945700-30057527ade0?auto=format&fit=crop&w=1200&q=80'
      }
    ]
  },
  vietnam: {
    heading: 'Grand Vietnam (7D / 6N) Heritage Trail',
    checkpoints: [
      {
        day: 'Days 01–02',
        title: 'Ho Chi Minh City & Cu Chi Tunnels',
        weather: '28°C • Tropical Urban Vibe',
        stay: '4★ District 1 Boutique Hotel',
        elev: 'Southern Delta Hub',
        meals: 'Breakfast + Guided Coach',
        desc: 'Visit the historic Reunification Palace, Notre Dame Cathedral, Saigon Central Post Office, and the legendary Cu Chi underground network.',
        img: 'https://images.unsplash.com/photo-1583417319070-4a69db38a482?auto=format&fit=crop&w=1200&q=80'
      },
      {
        day: 'Days 03–04',
        title: 'Da Nang & Ba Na Hills Golden Hands Bridge',
        weather: '20°C • Cloud Mountain Breeze',
        stay: '4★ My Khe Beachfront Hotel',
        elev: '4,878 ft • Ba Na Peak',
        meals: 'Buffet Lunch + Cable Car',
        desc: 'Fly to coastal Da Nang and ride the record-breaking cable car to the French Village and the iconic Golden Bridge held by giant stone hands.',
        img: 'https://images.unsplash.com/photo-1559592413-7cec4d0cae2b?auto=format&fit=crop&w=1200&q=80'
      },
      {
        day: 'Days 05–07',
        title: 'Marble Mountains, Cam Thanh Coconut Forest & Hoi An',
        weather: '25°C • Silk Lantern Evening',
        stay: '4★ Hoi An / Da Nang Resort',
        elev: 'UNESCO Ancient Port',
        meals: 'Breakfast + Lantern Boat',
        desc: 'Climb the five limestone peaks of Marble Mountains, spin in bamboo basket boats, and release floating lanterns in Hoi An Ancient Town.',
        img: 'https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=1200&q=80'
      }
    ]
  }
};
