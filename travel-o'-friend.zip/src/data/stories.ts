export interface TravelStory {
  id: string;
  title: string;
  sub: string;
  headline: string;
  caption: string;
  img: string;
}

export const STORIES_DATA: TravelStory[] = [
  {
    id: 'darjeeling',
    title: 'Darjeeling @ ₹4,999',
    sub: '5D / 4N • Was ₹7,900/-',
    headline: 'Darjeeling Queen of Hills Mega Offer',
    caption: 'Book now to get the best offer! Includes Sleeper Train, 3★ Hotel, Daily Breakfast-Lunch-Dinner & Tiger Hill Sightseeing.',
    img: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 'kashmir',
    title: 'Kashmir @ ₹12,999',
    sub: '10D / 9N • Was ₹15,999/-',
    headline: '10-Day Kashmir Valley & Gulmarg',
    caption: 'All-inclusive Srinagar, Gulmarg, Sonmarg & Pahalgam tour with train tickets, 3★ hotels, and 3 meals daily.',
    img: 'https://images.unsplash.com/photo-1595815771614-ade9d652a65d?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 'bangkok',
    title: 'Bangkok-Pattaya ₹26,999',
    sub: '4D/3N or 5D/4N • Bestseller',
    headline: 'Bangkok & Pattaya Island Escape',
    caption: 'Includes Pattaya Coral Island speedboat, Alcazar Show, Bangkok Golden Buddha, 3★ Hotels & Daily Breakfast. 4D/3N @ ₹26,999/- or 5D/4N @ ₹30,999/-.',
    img: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 'phuquoc',
    title: 'Phu Quoc @ ₹48,999',
    sub: '4D/3N or 5D/4N • Island Gem',
    headline: 'Exotic Phu Quoc Island & Hon Thom Cable Car',
    caption: 'Includes 3★ Hotel, Daily Breakfast, All Pickups & Sightseeing Entry Fees. Experience Vietnam’s paradise island.',
    img: 'https://images.unsplash.com/photo-1559592413-7cec4d0cae2b?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 'vietnam',
    title: 'Vietnam @ ₹49,999',
    sub: '5D/4N or 8D/7N • UNESCO Special',
    headline: 'Ba Na Hills Golden Bridge & Ha Long Bay',
    caption: 'Choose 5D/4N (@ ₹49,999/-) or 8D/7N (@ ₹69,999/-) with 4-star stays, Ha Long Bay cruise, and Ba Na Hills cable car!',
    img: 'https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=900&q=80'
  }
];
