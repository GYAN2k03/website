import React from 'react';
import { X, CheckCircle2, MessageCircle } from 'lucide-react';
import { TourPackage } from '../data/packages';

interface ItineraryModalProps {
  pkg: TourPackage | null;
  isOpen: boolean;
  onClose: () => void;
  onBook: (pkg: TourPackage) => void;
}

export const ItineraryModal: React.FC<ItineraryModalProps> = ({
  pkg,
  isOpen,
  onClose,
  onBook
}) => {
  if (!isOpen || !pkg) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4">
      <div
        className="cos-glass-strong rounded-3xl max-w-2xl w-full p-6 sm:p-8 max-h-[90vh] overflow-y-auto border-2 border-white shadow-2xl animate-in fade-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-bold uppercase tracking-wider">
              {pkg.part === 'international'
                ? 'Part 02 • International Tour • '
                : 'Part 01 • Domestic Special Offer • '}
              {pkg.duration}
            </span>
            <h3 className="font-display font-bold text-2xl sm:text-3xl text-slate-900 mt-2">
              {pkg.title}
            </h3>
            {pkg.bengaliName && (
              <span className="text-sm font-bold text-purple-600 block mt-1">{pkg.bengaliName}</span>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white shadow flex items-center justify-center text-slate-500 hover:text-slate-900 transition-colors"
            aria-label="Close Itinerary Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative h-56 rounded-2xl overflow-hidden mb-4 shadow">
          <img
            src={pkg.image}
            alt={pkg.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />
          <div className="absolute bottom-3 left-4 right-4 text-white">
            <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-black/40 backdrop-blur-md">
              {pkg.extraNote}
            </span>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5 font-medium">
          {pkg.overview}
        </p>

        <div className="bg-white/85 rounded-2xl p-4 sm:p-5 border border-white mb-6 shadow-sm">
          <h4 className="text-xs font-bold uppercase tracking-wider text-purple-700 mb-3">
            Day-by-Day Itinerary & Program
          </h4>
          <div className="space-y-2.5 text-xs font-semibold text-slate-700">
            {pkg.itinerary.map((step, idx) => (
              <div key={idx} className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50/80 border border-slate-100">
                <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                <span>{step}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3 border-t border-slate-200">
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400 block">
              Package Rate / Person
            </span>
            <div className="flex items-baseline gap-2">
              {pkg.oldPrice && (
                <span className="text-sm text-rose-500 line-through">
                  ₹{pkg.oldPrice.toLocaleString('en-IN')}/-
                </span>
              )}
              <span className="font-display font-extrabold text-2xl sm:text-3xl text-slate-900">
                ₹{pkg.price.toLocaleString('en-IN')}/-
              </span>
              <span className="text-xs text-slate-500 font-semibold">per person</span>
            </div>
            {pkg.tierOptions && (
              <span className="text-xs font-bold text-purple-600 block mt-0.5">
                {pkg.tierOptions}
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={() => {
              onClose();
              onBook(pkg);
            }}
            className="cos-gradient-btn w-full sm:w-auto px-7 py-3.5 rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Book Package on WhatsApp</span>
          </button>
        </div>
      </div>
    </div>
  );
};
