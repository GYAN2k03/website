import React, { useState } from 'react';
import { Route, ChevronRight } from 'lucide-react';
import { ROUTE_TRACKS } from '../data/routes';

export const RouteVisualizer: React.FC = () => {
  const [activeRouteKey, setActiveRouteKey] = useState<'kashmir' | 'vietnam'>('kashmir');
  const [selectedCheckpointIndex, setSelectedCheckpointIndex] = useState(0);

  const currentTrack = ROUTE_TRACKS[activeRouteKey];
  const activeCheckpoint = currentTrack.checkpoints[selectedCheckpointIndex] || currentTrack.checkpoints[0];

  const handleRouteSwitch = (key: 'kashmir' | 'vietnam') => {
    setActiveRouteKey(key);
    setSelectedCheckpointIndex(0);
  };

  return (
    <div className="cos-glass-strong rounded-3xl p-6 sm:p-10 shadow-lg">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-8">
        <div>
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-bold uppercase tracking-wider mb-2">
            <Route className="w-3.5 h-3.5" /> Interactive Route Map
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900">
            {currentTrack.heading}
          </h2>
        </div>

        <div className="flex items-center gap-2 bg-purple-100/60 p-1.5 rounded-full border border-white">
          <button
            type="button"
            onClick={() => handleRouteSwitch('kashmir')}
            className={`px-5 py-2 rounded-full text-xs font-bold transition-all ${
              activeRouteKey === 'kashmir'
                ? 'bg-slate-900 text-white shadow'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            Kashmir 10D/9N
          </button>
          <button
            type="button"
            onClick={() => handleRouteSwitch('vietnam')}
            className={`px-5 py-2 rounded-full text-xs font-bold transition-all ${
              activeRouteKey === 'vietnam'
                ? 'bg-slate-900 text-white shadow'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            Vietnam 7D/6N
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Day Checkpoints List */}
        <div className="lg:col-span-5 space-y-3">
          {currentTrack.checkpoints.map((cp, idx) => {
            const isSelected = idx === selectedCheckpointIndex;
            return (
              <button
                key={idx}
                type="button"
                onClick={() => setSelectedCheckpointIndex(idx)}
                className={`w-full text-left p-4 rounded-2xl transition-all flex items-center justify-between gap-3 border ${
                  isSelected
                    ? 'bg-white border-white shadow-md'
                    : 'bg-white/50 hover:bg-white/80 border-white/60'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <span
                    className={`w-10 h-10 rounded-xl font-display font-bold text-xs flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-gradient-to-br from-purple-500 to-cyan-400 text-white shadow-sm'
                        : 'bg-white text-slate-700'
                    }`}
                  >
                    0{idx + 1}
                  </span>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 block">
                      {cp.day}
                    </span>
                    <h4 className="font-display font-bold text-sm sm:text-base text-slate-900">
                      {cp.title}
                    </h4>
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 shrink-0 ${isSelected ? 'text-purple-600' : 'text-slate-400'}`} />
              </button>
            );
          })}
        </div>

        {/* Active Checkpoint Preview Card */}
        <div className="lg:col-span-7">
          <div className="cos-glass rounded-2xl p-4 sm:p-6 border border-white shadow-sm">
            <div className="relative h-64 sm:h-80 rounded-2xl overflow-hidden mb-5">
              <img
                src={activeCheckpoint.img}
                alt={activeCheckpoint.title}
                className="w-full h-full object-cover transition-all duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-transparent" />
              <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                <span className="px-3.5 py-1 rounded-full bg-white text-slate-900 text-xs font-bold shadow">
                  {activeCheckpoint.day}
                </span>
                <span className="px-3.5 py-1 rounded-full bg-slate-900/75 backdrop-blur-md text-cyan-200 text-xs font-semibold border border-white/20">
                  {activeCheckpoint.weather}
                </span>
              </div>
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <h3 className="font-display font-bold text-xl sm:text-2xl">
                  {activeCheckpoint.title}
                </h3>
              </div>
            </div>

            <p className="text-sm text-slate-600 leading-relaxed mb-5 font-medium">
              {activeCheckpoint.desc}
            </p>

            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-white">
              <div className="bg-white/80 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold uppercase text-slate-400 block">Accommodation</span>
                <span className="text-xs font-bold text-slate-900 mt-0.5 block">{activeCheckpoint.stay}</span>
              </div>
              <div className="bg-white/80 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold uppercase text-slate-400 block">Elevation / Vibe</span>
                <span className="text-xs font-bold text-purple-600 mt-0.5 block">{activeCheckpoint.elev}</span>
              </div>
              <div className="bg-white/80 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold uppercase text-slate-400 block">Meals & Transfers</span>
                <span className="text-xs font-bold text-slate-900 mt-0.5 block">{activeCheckpoint.meals}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
