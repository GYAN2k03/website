import React, { useEffect, useState } from 'react';
import { X, MessageCircle } from 'lucide-react';
import { STORIES_DATA } from '../data/stories';

interface StoryViewerModalProps {
  initialIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onBookStory: (storyId: string) => void;
}

export const StoryViewerModal: React.FC<StoryViewerModalProps> = ({
  initialIndex,
  isOpen,
  onClose,
  onBookStory
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);

  useEffect(() => {
    setCurrentIndex(initialIndex);
  }, [initialIndex]);

  useEffect(() => {
    if (!isOpen) return;

    const timer = setTimeout(() => {
      if (currentIndex < STORIES_DATA.length - 1) {
        setCurrentIndex(prev => prev + 1);
      } else {
        onClose();
      }
    }, 5500);

    return () => clearTimeout(timer);
  }, [isOpen, currentIndex, onClose]);

  if (!isOpen) return null;

  const story = STORIES_DATA[currentIndex];
  if (!story) return null;

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (currentIndex < STORIES_DATA.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xl p-4">
      <div
        className="relative w-full max-w-[24rem] h-[84vh] max-h-[46rem] rounded-3xl overflow-hidden bg-slate-900 border-2 border-white/30 shadow-2xl flex flex-col justify-between"
        onClick={e => e.stopPropagation()}
      >
        {/* Fullscreen Background Image with Scrim */}
        <img
          src={story.img}
          alt={story.title}
          className="absolute inset-0 w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/25 to-slate-950/60" />

        {/* Top Progress Bars & Header */}
        <div className="relative z-20 p-4 space-y-3">
          <div className="flex gap-1.5">
            {STORIES_DATA.map((_, idx) => (
              <div key={idx} className="h-1 flex-1 rounded-full bg-white/25 overflow-hidden">
                <div
                  className={`h-full bg-white transition-all duration-300 ${
                    idx < currentIndex ? 'w-full' : idx === currentIndex ? 'w-full' : 'w-0'
                  }`}
                />
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-cyan-400 text-white font-display font-bold text-xs flex items-center justify-center shadow">
                TOF
              </span>
              <div>
                <h4 className="font-display font-bold text-sm text-white leading-none">{story.title}</h4>
                <span className="text-[11px] text-cyan-300 font-medium">{story.sub}</span>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/20 text-white flex items-center justify-center hover:bg-white/30 transition-colors"
              aria-label="Close Story"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Left & Right Interactive Tap Zones */}
        <div className="absolute inset-y-20 inset-x-0 z-10 flex">
          <div
            onClick={handlePrev}
            className="w-1/3 h-full cursor-pointer"
            title="Previous Story"
          />
          <div
            onClick={handleNext}
            className="w-2/3 h-full cursor-pointer"
            title="Next Story"
          />
        </div>

        {/* Bottom Caption & Action */}
        <div className="relative z-20 p-5 space-y-3">
          <span className="inline-block px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-bold border border-white/30">
            {story.sub}
          </span>
          <h3 className="font-display font-bold text-2xl text-white leading-tight">{story.headline}</h3>
          <p className="text-xs text-slate-200 leading-relaxed font-medium">{story.caption}</p>
          <button
            type="button"
            onClick={() => {
              onClose();
              onBookStory(story.id);
            }}
            className="cos-gradient-btn w-full py-3.5 rounded-2xl font-display font-bold text-xs flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Enquire This Story on WhatsApp</span>
          </button>
        </div>
      </div>
    </div>
  );
};
