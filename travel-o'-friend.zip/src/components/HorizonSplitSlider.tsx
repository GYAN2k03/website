import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Sun, Moon, MoveHorizontal } from 'lucide-react';

export const HorizonSplitSlider: React.FC = () => {
  const [splitPercent, setSplitPercent] = useState(52);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const updateSplit = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setSplitPercent(Math.max(8, Math.min(92, pct)));
  }, []);

  const handlePointerDown = (e: React.PointerEvent) => {
    isDragging.current = true;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    updateSplit(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging.current) return;
    updateSplit(e.clientX);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    isDragging.current = false;
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  return (
    <div className="cos-glass-strong p-3 sm:p-5 rounded-3xl mb-10 shadow-lg">
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="relative h-[20rem] sm:h-[26rem] lg:h-[30rem] w-full rounded-2xl overflow-hidden select-none cursor-ew-resize touch-none"
      >
        {/* Night Layer (Base) */}
        <img
          src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=85"
          alt="Starlit Night Ambiance"
          className="absolute inset-0 w-full h-full object-cover brightness-75 contrast-125"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent pointer-events-none" />
        <div className="absolute top-4 right-4 z-20 px-4 py-2 rounded-full bg-slate-900/75 backdrop-blur-md text-white text-xs font-bold border border-white/20 flex items-center gap-2 pointer-events-none">
          <Moon className="w-4 h-4 text-cyan-300" />
          <span>Starlit Night Mode</span>
        </div>

        {/* Day Layer (Clipped Overlay) */}
        <div
          className="absolute inset-0 overflow-hidden pointer-events-none"
          style={{ width: `${splitPercent}%` }}
        >
          <img
            src="https://images.unsplash.com/photo-1595815771614-ade9d652a65d?auto=format&fit=crop&w=1600&q=85"
            alt="Golden Sunrise on Dal Lake"
            className="h-full object-cover max-w-none"
            style={{ width: containerRef.current ? `${containerRef.current.offsetWidth}px` : '100vw' }}
            referrerPolicy="no-referrer"
          />
          <div className="absolute top-4 left-4 z-20 px-4 py-2 rounded-full bg-white/90 backdrop-blur-md text-slate-900 text-xs font-bold shadow flex items-center gap-2">
            <Sun className="w-4 h-4 text-amber-500" />
            <span>Golden Sunrise Mode</span>
          </div>
        </div>

        {/* Slider Divider Handle */}
        <div
          className="absolute top-0 bottom-0 z-30 w-1 bg-white shadow-[0_0_20px_rgba(255,255,255,0.9)] pointer-events-none"
          style={{ left: `${splitPercent}%` }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white text-purple-600 shadow-lg border-2 border-purple-200 flex items-center justify-center">
            <MoveHorizontal className="w-5 h-5" />
          </div>
        </div>

        {/* Quick Preset Buttons */}
        <div className="absolute bottom-4 left-4 right-4 z-30 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
          <span className="px-4 py-2 rounded-full bg-black/45 backdrop-blur-md text-white text-xs font-semibold">
            Drag slider or tap presets
          </span>
          <div className="flex items-center gap-2 pointer-events-auto bg-white/30 backdrop-blur-xl p-1.5 rounded-full border border-white/50">
            <button
              type="button"
              onClick={() => setSplitPercent(85)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                splitPercent > 70 ? 'bg-white text-slate-900 shadow' : 'text-white hover:bg-white/20'
              }`}
            >
              Sunrise
            </button>
            <button
              type="button"
              onClick={() => setSplitPercent(50)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                splitPercent >= 40 && splitPercent <= 60
                  ? 'bg-white text-slate-900 shadow'
                  : 'text-white hover:bg-white/20'
              }`}
            >
              50 / 50
            </button>
            <button
              type="button"
              onClick={() => setSplitPercent(15)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                splitPercent < 30 ? 'bg-white text-slate-900 shadow' : 'text-white hover:bg-white/20'
              }`}
            >
              Starlight
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
