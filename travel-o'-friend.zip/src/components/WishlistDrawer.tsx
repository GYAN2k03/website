import React from 'react';
import { X, Heart, Trash2, Send } from 'lucide-react';
import { TourPackage } from '../data/packages';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  savedPackages: TourPackage[];
  onRemove: (id: string) => void;
  onSendWhatsApp: () => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  savedPackages,
  onRemove,
  onSendWhatsApp
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity"
      />
      <div className="absolute right-0 top-0 bottom-0 w-full max-w-md cos-glass-strong p-6 flex flex-col justify-between border-l-2 border-white shadow-2xl rounded-l-3xl">
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center">
                <Heart className="w-5 h-5 fill-purple-600" />
              </div>
              <div>
                <h3 className="font-display font-bold text-lg text-slate-900">Saved Tour Shortlist</h3>
                <span className="text-[11px] text-slate-500">
                  {savedPackages.length} package{savedPackages.length === 1 ? '' : 's'} selected
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white shadow flex items-center justify-center text-slate-500 hover:text-slate-800"
              aria-label="Close Wishlist"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="py-5 space-y-3 max-h-[65vh] overflow-y-auto no-scrollbar">
            {savedPackages.length === 0 ? (
              <p className="text-xs font-semibold text-slate-500 text-center py-10">
                Your shortlist is empty. Tap the heart icon on any tour card to save it here.
              </p>
            ) : (
              savedPackages.map(pkg => (
                <div
                  key={pkg.id}
                  className="p-3.5 rounded-2xl bg-white border border-slate-100 shadow-sm flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={pkg.image}
                      alt={pkg.title}
                      className="w-12 h-12 rounded-xl object-cover shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0">
                      <span className="text-[10px] font-bold uppercase text-purple-600 block">
                        {pkg.duration}
                      </span>
                      <h4 className="font-display font-bold text-xs text-slate-900 truncate">
                        {pkg.title}
                      </h4>
                      <span className="text-xs font-bold text-slate-700">
                        ₹{pkg.price.toLocaleString('en-IN')}/- PP
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemove(pkg.id)}
                    className="w-8 h-8 rounded-full bg-slate-100 hover:bg-rose-50 text-slate-400 hover:text-rose-600 flex items-center justify-center shrink-0 transition-colors"
                    title="Remove from shortlist"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {savedPackages.length > 0 && (
          <button
            type="button"
            onClick={onSendWhatsApp}
            className="cos-gradient-btn w-full py-4 rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Send Shortlist to WhatsApp (+91 80175 59717)</span>
          </button>
        )}
      </div>
    </div>
  );
};
