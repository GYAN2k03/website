import React, { useState } from 'react';
import { Calculator, CheckCircle2, Send } from 'lucide-react';

type TierType = 'comfort' | 'luxe' | 'royal';

export const BudgetEstimator: React.FC = () => {
  const [travelers, setTravelers] = useState(4);
  const [days, setDays] = useState(6);
  const [tier, setTier] = useState<TierType>('comfort');
  const [addonCandlelight, setAddonCandlelight] = useState(false);
  const [addonPhoto, setAddonPhoto] = useState(false);

  const basePerDay: Record<TierType, number> = {
    comfort: 3200,
    luxe: 4600,
    royal: 6800
  };

  const tierNames: Record<TierType, string> = {
    comfort: 'Smart Comfort Package (3★ Hotels & Group Coach)',
    luxe: 'Premium Luxe Package (4★ Boutique & Pvt SUV)',
    royal: 'Royal Private Sanctuary (5★ Luxury Villas & Chauffeur)'
  };

  let perPerson = days * basePerDay[tier];
  if (addonCandlelight) perPerson += 3500;
  if (addonPhoto) perPerson += 4500;

  const totalCost = perPerson * travelers;

  const handleSendWhatsApp = () => {
    const text =
      `Hello Travel O' Friend! I created a custom quote on your Trip Estimator:\n` +
      `• Tier: ${tierNames[tier]}\n` +
      `• Travelers: ${travelers} Persons\n` +
      `• Duration: ${days} Days / ${days - 1} Nights\n` +
      `• Add-ons: ${addonCandlelight ? 'Candlelight Dinner (+₹3,500) ' : ''}${addonPhoto ? 'Drone & Reel Shoot (+₹4,500)' : ''}${!addonCandlelight && !addonPhoto ? 'None' : ''}\n` +
      `• Estimated Total: ₹${totalCost.toLocaleString('en-IN')}/- (Approx. ₹${perPerson.toLocaleString('en-IN')}/- PP)\n` +
      `Please share customized itinerary and available dates!`;
    const url = `https://wa.me/918017559717?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="cos-glass-strong rounded-3xl p-6 sm:p-10 shadow-lg">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
        {/* Left Controls */}
        <div className="lg:col-span-7 space-y-6">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-cyan-500/15 text-cyan-700 text-xs font-bold uppercase tracking-wider mb-2">
              <Calculator className="w-3.5 h-3.5" /> Smart Trip Estimator
            </span>
            <h2 className="font-display font-bold text-3xl sm:text-4xl text-slate-900">
              Interactive Trip Budget{' '}
              <span className="font-serif-italic font-normal text-purple-600">& Tier Simulator</span>
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Customize travelers, duration, comfort tier, and optional add-ons for an instant transparent INR quote.
            </p>
          </div>

          {/* Sliders: Travelers & Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="cos-glass p-4 rounded-2xl">
              <div className="flex justify-between items-center mb-2">
                <label htmlFor="simTravelersInput" className="text-xs font-bold text-slate-600">
                  Number of Travelers
                </label>
                <span className="font-display font-bold text-sm text-purple-600">
                  {travelers} {travelers === 1 ? 'Traveler' : 'Travelers'}
                </span>
              </div>
              <input
                id="simTravelersInput"
                type="range"
                min={1}
                max={12}
                value={travelers}
                onChange={e => setTravelers(Number(e.target.value))}
                className="w-full"
              />
            </div>

            <div className="cos-glass p-4 rounded-2xl">
              <div className="flex justify-between items-center mb-2">
                <label htmlFor="simDaysInput" className="text-xs font-bold text-slate-600">
                  Trip Duration
                </label>
                <span className="font-display font-bold text-sm text-blue-600">
                  {days} Days / {days - 1} Nights
                </span>
              </div>
              <input
                id="simDaysInput"
                type="range"
                min={3}
                max={15}
                value={days}
                onChange={e => setDays(Number(e.target.value))}
                className="w-full"
              />
            </div>
          </div>

          {/* Tier Cards */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2.5">
              Select Experience Tier
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setTier('comfort')}
                className={`p-4 rounded-2xl text-left transition-all ${
                  tier === 'comfort'
                    ? 'border-2 border-purple-500 bg-white shadow-md'
                    : 'border border-white bg-white/60 hover:bg-white/80'
                }`}
              >
                <span className="text-[10px] font-bold uppercase text-purple-600 block">Tier 01</span>
                <span className="font-display font-bold text-base text-slate-900 block mt-0.5">
                  Smart Comfort
                </span>
                <span className="text-xs text-slate-500">3★ Hotels & Group Coach</span>
              </button>

              <button
                type="button"
                onClick={() => setTier('luxe')}
                className={`p-4 rounded-2xl text-left transition-all ${
                  tier === 'luxe'
                    ? 'border-2 border-blue-500 bg-white shadow-md'
                    : 'border border-white bg-white/60 hover:bg-white/80'
                }`}
              >
                <span className="text-[10px] font-bold uppercase text-blue-600 block">Tier 02</span>
                <span className="font-display font-bold text-base text-slate-900 block mt-0.5">
                  Premium Luxe
                </span>
                <span className="text-xs text-slate-500">4★ Boutique & Pvt SUV</span>
              </button>

              <button
                type="button"
                onClick={() => setTier('royal')}
                className={`p-4 rounded-2xl text-left transition-all ${
                  tier === 'royal'
                    ? 'border-2 border-amber-500 bg-white shadow-md'
                    : 'border border-white bg-white/60 hover:bg-white/80'
                }`}
              >
                <span className="text-[10px] font-bold uppercase text-amber-600 block">Tier 03</span>
                <span className="font-display font-bold text-base text-slate-900 block mt-0.5">
                  Royal Sanctuary
                </span>
                <span className="text-xs text-slate-500">5★ Luxury Villas & Chauffeur</span>
              </button>
            </div>
          </div>

          {/* Optional Add-ons */}
          <div className="flex flex-wrap gap-3">
            <label className="cos-glass px-4 py-2.5 rounded-xl flex items-center gap-2.5 cursor-pointer text-xs font-bold text-slate-900 hover:bg-white transition-colors">
              <input
                type="checkbox"
                checked={addonCandlelight}
                onChange={e => setAddonCandlelight(e.target.checked)}
                className="accent-purple-600 w-4 h-4 rounded"
              />
              <span>+ Candlelight Dinner / Cruise (+₹3,500)</span>
            </label>
            <label className="cos-glass px-4 py-2.5 rounded-xl flex items-center gap-2.5 cursor-pointer text-xs font-bold text-slate-900 hover:bg-white transition-colors">
              <input
                type="checkbox"
                checked={addonPhoto}
                onChange={e => setAddonPhoto(e.target.checked)}
                className="accent-purple-600 w-4 h-4 rounded"
              />
              <span>+ Drone & Reel Shoot (+₹4,500)</span>
            </label>
          </div>
        </div>

        {/* Right Live Output Card */}
        <div className="lg:col-span-5">
          <div className="rounded-3xl bg-gradient-to-br from-purple-100 via-sky-100 to-cyan-100 p-7 sm:p-8 border-2 border-white shadow-xl relative overflow-hidden">
            <div className="flex items-center justify-between pb-4 mb-5 border-b border-white/70">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-purple-700 block">
                  Live Estimate
                </span>
                <h3 className="font-display font-bold text-lg text-slate-900">
                  {tier === 'comfort' && 'Smart Comfort Package'}
                  {tier === 'luxe' && 'Premium Luxe Package'}
                  {tier === 'royal' && 'Royal Private Sanctuary'}
                </h3>
              </div>
              <span className="px-3 py-1 rounded-full bg-white text-slate-900 text-[10px] font-bold shadow-sm">
                All-Inclusive
              </span>
            </div>

            <div className="mb-6">
              <span className="text-xs font-semibold text-slate-600 block">Total Group Estimate</span>
              <div className="font-display font-extrabold text-4xl sm:text-5xl text-slate-900 tracking-tight mt-1">
                ₹{totalCost.toLocaleString('en-IN')}/-
              </div>
              <p className="text-xs font-bold text-purple-700 mt-1.5">
                Approx. ₹{perPerson.toLocaleString('en-IN')}/- per traveler
              </p>
            </div>

            <ul className="space-y-2 text-xs font-semibold text-slate-700 mb-6">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                <span>Handpicked Stays + Daily Meals Included</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                <span>Sightseeing Transfers, Permits & Toll Taxes</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                <span>24/7 Dedicated Tour Ground Coordinator</span>
              </li>
            </ul>

            <button
              type="button"
              onClick={handleSendWhatsApp}
              className="cos-gradient-btn w-full py-4 rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Send Custom Quote to WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
