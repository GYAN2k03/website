import React, { useState } from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ className = '', size = 'md' }) => {
  const [hasError, setHasError] = useState(false);

  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-14 h-14 sm:w-16 sm:h-16',
    lg: 'w-20 h-20 sm:w-24 sm:h-24',
    xl: 'w-28 h-28'
  }[size];

  // User provided official logo
  const logoPath = '/assets/aistudio/logo.jpg_fbe72653.jpg';

  if (!hasError) {
    return (
      <div
        className={`relative overflow-hidden rounded-2xl bg-white p-0.5 border border-white shadow-md flex items-center justify-center shrink-0 ${sizeClasses} ${className}`}
      >
        <img
          src={logoPath}
          alt="Travel O' Friend Official Brand Logo"
          className="w-full h-full object-contain rounded-xl"
          referrerPolicy="no-referrer"
          onError={() => setHasError(true)}
        />
      </div>
    );
  }

  // Graceful fallback SVG
  return (
    <div
      className={`relative overflow-hidden rounded-2xl bg-white p-0.5 border border-white shadow-md flex items-center justify-center shrink-0 ${sizeClasses} ${className}`}
    >
      <svg
        className="w-full h-full"
        viewBox="0 0 500 500"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        role="img"
        aria-label="Travel O' Friend Official Logo"
      >
        <defs>
          <linearGradient id="tofSunGrad" x1="160" y1="80" x2="340" y2="270" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#F58220" />
            <stop offset="55%" stopColor="#F99D1C" />
            <stop offset="100%" stopColor="#FBB03B" />
          </linearGradient>
          <linearGradient id="tofSunShadow" x1="170" y1="100" x2="320" y2="250" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#D9531E" />
            <stop offset="100%" stopColor="#F58220" />
          </linearGradient>
          <linearGradient id="tofOceanBlue" x1="80" y1="140" x2="410" y2="350" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#064E8C" />
            <stop offset="50%" stopColor="#0B65AF" />
            <stop offset="100%" stopColor="#1074BC" />
          </linearGradient>
        </defs>
        <rect x="8" y="8" width="484" height="484" rx="36" fill="#FFFFFF" stroke="#1074BC" strokeWidth="14" />
        <path
          d="M214 218 C196 196, 196 160, 222 142 C240 129, 258 145, 240 162 C258 164, 282 148, 294 128 C275 110, 244 104, 218 116 C182 132, 174 184, 214 218 Z"
          fill="url(#tofSunShadow)"
          opacity="0.88"
        />
        <path
          d="M212 214 C188 186, 192 136, 232 114 C264 96, 308 106, 326 130 C306 122, 282 126, 266 144 C254 156, 258 168, 236 164 C216 160, 206 186, 212 214 Z"
          fill="url(#tofSunGrad)"
        />
        <path
          d="M208 228 C236 258, 294 258, 324 224 C344 202, 346 168, 338 148 C338 178, 324 206, 300 218 C282 226, 276 212, 292 204 C272 204, 254 222, 208 228 Z"
          fill="url(#tofSunGrad)"
        />
        <path
          d="M126 226 C164 198, 212 228, 254 222 C284 218, 302 196, 314 172 L292 172 L302 158 L324 160 L334 142 C338 136, 346 140, 342 148 L334 166 L346 196 L336 206 L324 180 C308 212, 282 238, 244 238 C202 238, 162 212, 126 226 Z"
          fill="url(#tofOceanBlue)"
        />
        <text x="86" y="328" fontFamily="'Great Vibes', cursive" fontSize="136" fontWeight="400" fill="url(#tofOceanBlue)">
          T
        </text>
        <text
          x="175"
          y="324"
          fontFamily="'Instrument Serif', Georgia, serif"
          fontStyle="italic"
          fontWeight="700"
          fontSize="118"
          fill="url(#tofOceanBlue)"
          letterSpacing="1"
        >
          ravel
        </text>
        <text x="164" y="408" fontFamily="'Great Vibes', cursive" fontSize="86" fill="url(#tofSunGrad)" letterSpacing="1.5">
          O' Friend
        </text>
      </svg>
    </div>
  );
};
